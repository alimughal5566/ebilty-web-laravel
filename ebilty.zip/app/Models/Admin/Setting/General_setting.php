<?php

namespace App\Models\Admin\Setting;

use Illuminate\Database\Eloquent\Model;

class  General_setting extends Model
{
    //
}
