<?php
namespace App\Models\Admin\Setting;

use Illuminate\Database\Eloquent\Model;

class PackageType extends Model
{
    protected $table="shipment_package_types";
}
