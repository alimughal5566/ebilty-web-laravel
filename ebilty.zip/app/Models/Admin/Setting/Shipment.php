<?php

namespace App\Models\Admin\Setting;

use Illuminate\Database\Eloquent\Model;

class Shipment extends Model
{
   protected $table='shippments';
}
