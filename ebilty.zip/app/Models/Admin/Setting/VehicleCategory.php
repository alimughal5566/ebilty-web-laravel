<?php

namespace App\Models\Admin\Setting;

use Illuminate\Database\Eloquent\Model;

class VehicleCategory extends Model
{
    //
}
