<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShipmentArea extends Model
{
    protected $table='shipment_areas';
}
