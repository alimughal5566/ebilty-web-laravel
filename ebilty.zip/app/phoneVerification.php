<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class phoneVerification extends Model
{

    protected $table="phone_verifications";
    protected $guarded=['id'];
}
