<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\general_setting;
use Faker\Generator as Faker;

$factory->define(general_setting::class, function (Faker $faker) {
    return [
        //
    ];
});
