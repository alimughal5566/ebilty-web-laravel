<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PackageType;
use Faker\Generator as Faker;

$factory->define(PackageType::class, function (Faker $faker) {
    return [
        //
    ];
});
