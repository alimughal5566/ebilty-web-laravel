<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Admin\Setting\VehicleCategory;
use Faker\Generator as Faker;

$factory->define(VehicleCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
