<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Admin\Setting\Vehicle;
use Faker\Generator as Faker;

$factory->define(Vehicle::class, function (Faker $faker) {
    return [
        //
    ];
});
