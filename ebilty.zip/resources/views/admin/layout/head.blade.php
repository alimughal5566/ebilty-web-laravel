<head>
  <title>@yield('title','Ebilty')</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="{{asset('js')}}/jquery.min.js"></script>
  <link rel="stylesheet" href="{{asset('css')}}/bootstrap.min.css">
  <script src="{{asset('js')}}/jquery.min.js"></script>
  <script src="{{asset('js')}}/popper.min.js"></script>
  <script src="{{asset('js')}}/bootstrap.min.js"></script>
  <link rel="stylesheet" href="{{asset('css')}}/all.css"/>
  <link rel="stylesheet" href="{{asset('css')}}/line-awesome.min.css">
    <link rel="icon" href="{{url('/uploads/logos/favicon.png')}}">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="{{asset('css')}}/bootstrap-select.min.css">
  <!-- Latest compiled and minified JavaScript -->
  <script src="{{asset('js')}}/bootstrap-select.min.js"></script>
    <script src="{{asset('js')}}/boxicons.js"></script>
    <link href='{{asset('css')}}/boxicons.min.css' rel='stylesheet'>

  <link rel="stylesheet" href="{{asset('assets/css/custom_style.css')}}">
  <link rel="stylesheet" href="{{asset('assets/css/light.css')}}">
  <link rel="stylesheet" href="{{asset('assets/css/vendors.bundle.css')}}">
  <link rel="stylesheet" href="{{asset('assets/css/ns-default.css')}}">
  <link rel="stylesheet" href="{{asset('assets/css/ns-style-other.css')}}">
  <link rel="stylesheet" href="{{asset('assets/css/style.bundle.css')}}">
</head>
{{--<head>--}}
{{--    <title>@yield('title','Ebilty')</title>--}}
{{--    <meta charset="utf-8">--}}
{{--    <meta name="viewport" content="width=device-width, initial-scale=1">--}}
{{--    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>--}}
{{--    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">--}}
{{--    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>--}}
{{--    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>--}}
{{--    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>--}}
{{--    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>--}}
{{--    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">--}}
{{--    <link rel="icon" href="{{url('/uploads/logos/favicon.png')}}">--}}
{{--    <!-- Latest compiled and minified CSS -->--}}
{{--    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/css/bootstrap-select.min.css">--}}
{{--    <!-- Latest compiled and minified JavaScript -->--}}
{{--    <script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.14/dist/js/bootstrap-select.min.js"></script>--}}
{{--    <script src="https://unpkg.com/boxicons@latest/dist/boxicons.js"></script>--}}
{{--    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>--}}

{{--    <link rel="stylesheet" href="{{asset('assets/css/custom_style.css')}}">--}}
{{--    <link rel="stylesheet" href="{{asset('assets/css/light.css')}}">--}}
{{--    <link rel="stylesheet" href="{{asset('assets/css/vendors.bundle.css')}}">--}}
{{--    <link rel="stylesheet" href="{{asset('assets/css/ns-default.css')}}">--}}
{{--    <link rel="stylesheet" href="{{asset('assets/css/ns-style-other.css')}}">--}}
{{--    <link rel="stylesheet" href="{{asset('assets/css/style.bundle.css')}}">--}}
{{--</head>--}}
