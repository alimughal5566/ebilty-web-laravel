<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('admin.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="kt-quick-panel--right kt-demo-panel--right kt-offcanvas-panel--right kt-header--fixed kt-header-mobile--fixed kt-subheader--enabled kt-subheader--fixed kt-subheader--solid kt-aside--enabled kt-aside--fixed kt-header__topbar--mobile-on" data-new-gr-c-s-check-loaded="14.1012.0" data-gr-ext-installed="" style="">
    <!-- begin:: Page -->
    <!-- begin:: Header Mobile -->
    <div id="kt_header_mobile" class="kt-header-mobile  kt-header-mobile--fixed ">
       <div class="kt-header-mobile__logo">
          <a href="#">

          </a>
       </div>
       <div class="kt-header-mobile__toolbar">
          <button class="kt-header-mobile__toggler kt-header-mobile__toggler--left" id="kt_aside_mobile_toggler"><span></span></button>
          <button class="kt-header-mobile__toggler" id="kt_header_mobile_toggler"><span></span></button>
          <button class="kt-header-mobile__topbar-toggler kt-header-mobile__toolbar-topbar-toggler--active" id="kt_header_mobile_topbar_toggler"><i class="flaticon-more"></i></button>
       </div>
    </div>
    <!-- end:: Header Mobile -->
    <div class="kt-grid kt-grid--hor kt-grid--root">
       <div class="kt-grid__item kt-grid__item--fluid kt-grid kt-grid--ver kt-page">
          <?php echo $__env->make('admin/layout/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php echo $__env->make('admin/layout/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="kt-content  kt-grid__item kt-grid__item--fluid kt-grid kt-grid--hor" id="kt_content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
       </div>
    </div>
    <!-- end:: Page -->
    <!-- begin::Scrolltop -->
    <div id="kt_scrolltop" class="kt-scrolltop">
       <i class="fa fa-arrow-up"></i>
    </div>
    <!-- end::Scrolltop -->
    <!-- end::Global Config -->
    <!--begin::Global Theme Bundle(used by all pages) -->
    <script src="<?php echo e(asset('assets/js/modernizr.custom.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/js/classie.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/js/notificationFx.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/js/scripts.bundle.js')); ?>" type="text/javascript"></script>
    <!--end::Global Theme Bundle -->
    <!--begin::Page Scripts(used by this page) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ajax-bootstrap-select/1.3.8/js/ajax-bootstrap-select.min.js"></script>
    <script src="<?php echo e(asset('assets/js/framework.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/framework.extras.js')); ?>"></script>
    <link rel="stylesheet" property="stylesheet" href="#">

    <script>
        // channel.bind('App\\Events\\NotificationEvent', function(data) {
        //     console.log('sfddsfdsfsdf')
        //     // this is called when the event notification is received...
        // });

        function formatDate(date) {
            var d = new Date(date),
                month = '' + (d.getMonth() + 1),
                day = '' + d.getDate(),
                year = d.getFullYear();

            if (month.length < 2) month = '0' + month;
            if (day.length < 2) day = '0' + day;

            return [year, month, day].join('-');
        }




        function getnotification(){



            $.get( '<?php echo e(route('count.all.notification')); ?>', function( data ) {
                $('.noticount').text(data)
            });
            $.get( '<?php echo e(route('get.all.notification')); ?>', function( data ) {
                $('#notificationlist').empty();
                        // console.log(data.data)
                var html='';
                $.each(data.data, function (index, value) {
                    html +=`<a href="" class="kt-notification__item">
                     <div class="kt-notification__item-icon">
                        <i class="flaticon-gift kt-font-success"></i>
                     </div>
                     <div class="kt-notification__item-details">
                        <div class="kt-notification__item-title">`+value.message+`</div>
                    <div class="kt-notification__item-time kt-font-sm">`+formatDate(value.created_at)+`
                    </div>
                 </div>
              </a>`
                })
                $('#notificationlist').append(html);

            });
        }


    </script>
 </body>
 </html>
<?php /**PATH C:\xampp\htdocs\ebilty-laravel\resources\views/admin/layout/app.blade.php ENDPATH**/ ?>