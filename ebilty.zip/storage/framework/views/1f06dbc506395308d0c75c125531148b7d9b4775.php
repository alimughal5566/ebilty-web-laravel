
<?php $__env->startSection('content'); ?>
    
    <style>
        .progress {
            width: 100px;
            height: 100px;
            background: none;
            position: relative;
        }
        .progress::after {
            content: "";
            width: 100%;
            height: 100%;
            border-radius: 50%;
            border: 6px solid #eee;
            position: absolute;
            top: 0;
            left: 0;
        }

        .progress>span {
            width: 50%;
            height: 100%;
            overflow: hidden;
            position: absolute;
            top: 0;
            z-index: 1;
        }

        .progress .progress-left {
            left: 0;
        }

        .progress .progress-bar {
            width: 100%;
            height: 100%;
            background: none;
            border-width: 6px;
            border-style: solid;
            position: absolute;
            top: 0;
        }

        .progress .progress-left .progress-bar {
            left: 100%;
            border-top-right-radius: 80px;
            border-bottom-right-radius: 80px;
            border-left: 0;
            -webkit-transform-origin: center left;
            transform-origin: center left;
        }

        .progress .progress-right {
            right: 0;
        }

        .progress .progress-right .progress-bar {
            left: -100%;
            border-top-left-radius: 80px;
            border-bottom-left-radius: 80px;
            border-right: 0;
            -webkit-transform-origin: center right;
            transform-origin: center right;
        }

        .progress .progress-value {
            position: absolute;
            top: 0;
            left: 0;
        }

        /*
        *
        * ==========================================
        * FOR DEMO PURPOSE
        * ==========================================
        *
        */

        .rounded-lg {
            border-radius: 1rem;
        }

        .text-gray {
            color: #aaa;
        }

        div.h4 {
            line-height: 1rem;
        }

    </style>
    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
        <div class="kt-container  kt-container--fluid  ">
            <div class="kt-subheader__main">
                
                <span class="kt-subheader__separator kt-subheader__separator--v"></span>
                <div class="kt-subheader__breadcrumbs">
                    
                    
                    
                    
                    
                    
                    
                    
                    <a href="#" class="kt-subheader__breadcrumbs-home">
                        Shipment#<?php echo e(@$shipment->id); ?></a>
                    <span class="kt-subheader__breadcrumbs-link kt-subheader__breadcrumbs-link--active"></span>
                </div>
            </div>
            <div class="kt-subheader__toolbar">
                <div class="kt-subheader__wrapper">
                </div>
            </div>
        </div>
    </div>
    <div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">

        <div class="kt-portlet ">
            <div class="kt-portlet__body">
                <div class="kt-widget kt-widget--user-profile-3">
                    <div class="kt-widget__top">
                        <div class="kt-widget__content">
                            <div class="kt-widget__head">
                                <a href="javascript:;" class="kt-widget__username">

                                </a>
                                <div class="kt-widget__action">
                                    <a href="<?php echo e(route('downloadPdf',$shipment->id)); ?>" class="btn btn-label-brand btn-bold btn-sm" >
                                        <small class="fa fa-download"></small> Download
                                    </a>

                                        <!--begin::Nav-->

                                            <!-- <li class="kt-nav__item">
                                                <a href="javascript:;" data-toggle="modal" data-target="#paypal_modal" class="kt-nav__link">
                                                    <i class="kt-nav__link-icon flaticon-cancel"></i>
                                                    <span class="kt-nav__link-text">Pay</span>
                                                </a>
                                            </li> -->
                                            <!--                                                          <li class="kt-nav__item">
<a href="javascript:;" data-toggle="modal" data-target="#transfer_office" class="kt-nav__link">
<i class="kt-nav__link-icon flaticon-logout"></i>
<span class="kt-nav__link-text">Transfer To Branch</span>
</a>
</li>
-->






                                            <!--                                                     <li class="kt-nav__item">
    <a href="javascript:;" data-toggle="modal" data-target="#postpone" class="kt-nav__link">
        <i class="kt-nav__link-icon flaticon-refresh"></i>
        <span class="kt-nav__link-text">Postpone</span>
    </a>
</li>
-->
                                            <!--  -->


                                            <!--  -->








                                        <!--end::Nav-->

                                </div>
                            </div>

                            <div class="kt-widget__subhead float-right">
                                <?php if(file_exists(public_path('images/qrcodes/'.$shipment->id.'.svg'))): ?>
                                <?php echo file_get_contents(public_path('images/qrcodes/'.$shipment->id.'.svg')); ?>

                                <?php endif; ?>
                            </div>


































                            <div class="kt-widget__info">

                                <div class="kt-widget__stats d-flex align-items-center flex-fill">
                                    <div class="kt-widget__item">
                                <span class="kt-widget__date">
                                    Bids
                                </span>
                                        <div class="kt-widget__label notes_scroll">
                                            <span class="btn btn-label-brand btn-sm btn-bold btn-upper"><?php echo e($shipment->bids->count()); ?></span>
                                        </div>
                                    </div>
                                    <div class="kt-widget__item">
                                <span class="kt-widget__date">
                                    Created Date
                                </span>
                                        <div class="kt-widget__label">
                                            <span class="btn btn-label-brand btn-sm btn-bold btn-upper"><?php echo e($shipment->created_at->format('d/m/Y')); ?></span>
                                        </div>
                                    </div>
                                    <div class="kt-widget__item">
                                <span class="kt-widget__date">
                                    Last update
                                </span>
                                        <div class="kt-widget__label">
                                            <span class="btn btn-label-danger btn-sm btn-bold btn-upper"><?php echo e($shipment->updated_at->format('d/m/Y')); ?></span>
                                        </div>
                                    </div>
                    <?php $percentage=0;
                        if($shipment->status_id==1){
                        $percentage=30;
                        }
                        if($shipment->status_id==6){
                        $percentage=20;
                        }
                        if($shipment->status_id==4){
                        $percentage=40;
                        }
                        if($shipment->status_id==6){
                        $percentage=35;
                        }
                        if($shipment->status_id==8){
                        $percentage=100;
                        }
                        if($shipment->status_id==7){
                        $percentage=90;
                        }
                        if($shipment->status_id==3){
                        $percentage=50;
                        }
                                    ?>
                                    <div class="kt-widget__item flex-fill">
                                        <span class="kt-widget__subtitel">Progress</span>
                                        <div class="kt-widget__progress d-flex  align-items-center">
                                            <div class="progress" style="height: 5px;width: 100%;">
                                                <div class="progress-bar kt-bg-danger" role="progressbar" style="width: 30%;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                            <span class="kt-widget__stat">
                                        <?php echo e($percentage); ?>%
                                    </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end:: Portlet-->


        <div class="row">
            <div class="col-xl-6">
                <!--begin:: Widgets/Order Statistics-->
                <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                Order Details
                            </h3>
                        </div>
                    </div>
                    <div class="kt-portlet__body kt-portlet__body--fluid">
                        <div class="kt-widget12">
                            <div class="kt-widget12__content">
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Created by</span>
                                        <span class="kt-widget12__value">
                                        <?php echo e(ucfirst($shipment->user->name)); ?>

                                                                    </span>
                                    </div>
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Delivery Type</span>
                                        <span class="kt-widget12__value"><?php echo e(($shipment->dilivery_type==1)?'Vehicle':'Package'); ?></span>
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Status</span>
                                        <span class="kt-widget12__value">

                                     <span class=" btn-bold "></span><?php echo e($shipment->status->name); ?></span>
                                    </div>




                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Delivery</span>
                                        <span class="kt-widget12__value"><?php echo e($shipment->ship_date); ?> <?php echo e($shipment->ship_time); ?></span>
                                    </div>




                                </div>











                            </div>
                        </div>
                    </div>
                </div>
                <!--end:: Widgets/Order Statistics-->
            </div>
            <div class="col-xl-6">
                <!--begin:: Widgets/Order Statistics-->
                <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                Payment&amp;Items Details
                            </h3>
                        </div>
                    </div>
                    <div class="kt-portlet__body kt-portlet__body--fluid">
                        <div class="kt-widget12">
                            <div class="kt-widget12__content">

                                <!--                    start pay by paypal           -->





                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Shipping Cost</span>
                                        <span class="kt-widget12__value">
                                               $<?php echo e($shipment->shipping_fee); ?>

                                                </span>
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Total Requested From The Receiver</span>
                                        <span class="kt-widget12__value">
                                        $00<!-- <span class="btn btn-label-danger btn-sm btn-bold btn-upper" data-toggle="kt-tooltip" data-placement="top" title="The actual cost will be calculated when we receive the package" data-original-title="The actual cost will be calculated when we receive the package" data-skin="dark">Not confirmed yet</span>-->
                                                                            </span>
                                        <!--
                                            </span>
                                        -->
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Total Requested From The Sender</span>
                                        <span class="kt-widget12__value">
                                        $00<!-- <span class="btn btn-label-danger btn-sm btn-bold btn-upper" data-toggle="kt-tooltip" data-placement="top" title="The actual cost will be calculated when we receive the package" data-original-title="The actual cost will be calculated when we receive the package" data-skin="dark">Not confirmed yet</span>-->
                                                                            </span>
                                        <!--
                                                                                -->
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Total received</span>
                                        <span class="kt-widget12__value">$00</span>
                                    </div>
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Total remaining</span>
                                        <span class="kt-widget12__value">
                                                                                    $00
                                            <!--<span class="btn btn-label-danger btn-sm btn-bold btn-upper" data-toggle="kt-tooltip" data-placement="top" title="The actual cost will be calculated when we receive the package" data-original-title="The actual cost will be calculated when we receive the package" data-skin="dark">Not confirmed yet</span>-->
                                    </span>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end:: Widgets/Order Statistics-->
            </div>

        </div>
        <div class="row">
            <div class="col-xl-6">
                <!--begin:: Widgets/Order Statistics-->
                <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                Sender details
                            </h3>
                        </div>
                    </div>
                    <div class="kt-portlet__body kt-portlet__body--fluid">
                        <div class="kt-widget12">
                            <div class="kt-widget12__content">
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Name</span>
                                        <span class="kt-widget12__value">
                                            <?php echo e($shipment->sender->user->name); ?>

                                             </span>
                                    </div>
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Mobile</span>
                                        <span class="kt-widget12__value"><?php echo e($shipment->sender->user->phone); ?></span>
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Email</span>
                                        <span class="kt-widget12__value"><?php echo e($shipment->sender->user->email); ?></span>
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Sender Address</span>
                                        <span class="kt-widget12__value">
                                                           <?php echo e($shipment->sender->address); ?>

                                                                    </span>
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">State</span>
                                        <span class="kt-widget12__value">
                                            <?php echo e($shipment->sender->state->name); ?>

                                                                    </span>
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">City</span>
                                        <span class="kt-widget12__value"><?php echo e($shipment->sender->city->name); ?>

 </span>
                                    </div>
                                </div>










                            </div>
                        </div>
                    </div>
                </div>
                <!--end:: Widgets/Order Statistics-->
            </div>
            <div class="col-xl-6">
                <!--begin:: Widgets/Order Statistics-->
                <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                Receiver Details

                            </h3>
                        </div>
                    </div>
                    <div class="kt-portlet__body kt-portlet__body--fluid">
                        <div class="kt-widget12">
                            <div class="kt-widget12__content">
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Name</span>
                                        <span class="kt-widget12__value"><?php echo e($shipment->receiver->user->name); ?>

                                        </span>
                                    </div>
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Mobile</span>
                                        <span class="kt-widget12__value"><?php echo e($shipment->receiver->user->phone); ?></span>
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Email</span>
                                        <span class="kt-widget12__value"><?php echo e($shipment->receiver->user->email); ?></span>
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Receiver Address</span>
                                        <span class="kt-widget12__value">
                                            <?php echo e($shipment->receiver->address); ?>

                                                                            </span>
                                    </div>
                                </div>


                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">State</span>
                                        <span class="kt-widget12__value">
                                                <?php echo e($shipment->receiver->state->name); ?>

                                            </span>
                                    </div>
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">City</span>
                                        <span class="kt-widget12__value">
                                                <?php echo e($shipment->receiver->city->name); ?>

                                            </span>
                                    </div>
                                </div>









                            </div>
                        </div>
                    </div>
                </div>
                <!--end:: Widgets/Order Statistics-->
            </div>
            <?php if($shipment->packages->count()>0): ?>
            <div class="col-xl-12">
                <!--begin:: Widgets/Order Statistics-->
                <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                                Package Information
                            </h3>
                        </div>
                    </div>
                    <div class="kt-portlet__body kt-portlet__body--fluid">

                        <div class="kt-widget12">
                            <table class="table table-bordered">
                                <tr>
                                    <th>#</th>
                                    <th>Package Type</th>
                                    <th>Description</th>
                                    <th>weight</th>
                                    <th>Quantity</th>
                                    <th>Dimensions</th>
                                </tr>
                            <?php $__currentLoopData = $shipment->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      <td><?php echo e(++$i); ?></td>
                                      <td><?php echo e(@$package->category->name); ?></td>
                                      <td><?php echo e($package->description); ?></td>
                                      <td><?php echo e($package->weight); ?></td>
                                      <td><?php echo e($package->quantity); ?></td>
                                      <td><?php echo e($package->length); ?>x<?php echo e($package->width); ?>x<?php echo e($package->height); ?></td>
                                  </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end:: Widgets/Order Statistics-->
            </div>
            <?php endif; ?>
            <div class="col-xl-12">
                <!--begin:: Widgets/Order Statistics-->
                <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label ">
                            <h3 class="kt-portlet__head-title">
                                Location
                            </h3>
                        </div>
                        <button type="button" class="float-right text-right btn btn-warning btn-sm mb-1 mt-4"   style="max-height: 30px" onclick="getLatlong()">
                            Get Directions
                        </button>
                    </div>
                    <div class="kt-portlet__body kt-portlet__body--fluid">
                        <div class="kt-widget12">
                            <div class="kt-widget12__content">

                            <div class="kt-widget12__item">
                                <div class="kt-widget12__info">

                                    <div class="kt-widget15">

                                        <div class="kt-widget15__map">
                                            <div id="map"></div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end:: Widgets/Order Statistics-->
            </div>
        </div>
    </div>

    <style>
        #map {
            height: 500px;
            position: relative;
        }


    </style>
    
    
    

    <!-- The Modal -->

<?php
    $dist=abs($shipment->receiver->lat-$shipment->sender->lat);

        if($dist<1){
        $zoom=15;
    }      elseif($dist<2){
        $zoom=10;
    }  elseif($dist<3){
        $zoom=7;
    }elseif($dist<10){
        $zoom=5;
    }elseif($dist<30){
        $zoom=4;
    }else{
      $zoom=3;
    }

?>


    <script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyCoM2N8BXBveNHlX96-EjCkpaQDd7mVrLI&callback=initMap" async></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous"></script>

    <script>
    <?php if(\Session::has('success')): ?>
       toastr.success( 'Shipment Created successfully');
    <?php endif; ?>































    function getLatlong() {
        window.open("https://maps.google.com/maps/dir/<?php echo e($shipment->receiver->lat); ?>,<?php echo e($shipment->receiver->lng); ?>/<?php echo e($shipment->sender->lat); ?>,<?php echo e($shipment->sender->lng); ?>", "_blank");
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebilty-laravel\resources\views/user/shipment/show.blade.php ENDPATH**/ ?>