<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
          integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.0/css/all.css"
          integrity="sha384-REHJTs1r2ErKBuJB0fCK99gCYsVjwxHrSU0N7I1zl9vZbggVJXRMsv/sLlOAGb4M" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">

    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
        <div class="kt-container  kt-container--fluid  ">
            <div class="kt-subheader__main">
                
                <span class="kt-subheader__separator kt-subheader__separator--v"></span>
                <div class="kt-subheader__breadcrumbs">
                    
                    
                    
                    
                    
                    
                    
                    
                    <a href="#" class="kt-subheader__breadcrumbs-home">
                        Shipments</a>
                    <span class="kt-subheader__breadcrumbs-link kt-subheader__breadcrumbs-link--active">Create New Shipment</span>
                </div>
            </div>
            <div class="kt-subheader__toolbar">
                <div class="kt-subheader__wrapper">
                </div>
            </div>
        </div>
    </div>
    <div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
        <form method="POST" action="<?php echo e(route('create.shipment')); ?>"  enctype="multipart/form-data" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="kt-portlet kt-portlet--mobile">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <div class="kt-portlet__head panel-title" data-toggle="collapse" data-target="#collapseOne">
                                    <div class="kt-portlet__head-label">
                                        <h3 class="kt-portlet__head-title">
                                            Shipment information
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div id="collapseOne" class="panel-collapse collapse show">
                                <div class="panel-body">
                                    <div class="kt-portlet__body">
                                        <div class="form-group form-group-last kt-hide">
                                            <div class="alert alert-danger kt_form_msg" role="alert">
                                                <div class="alert-icon"><i class="flaticon-warning"></i></div>
                                                <div class="alert-text">
                                                    Oh snap! Change a few things up and try submitting again.
                                                </div>
                                                <div class="alert-close">
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true"><i class="la la-close"></i></span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="kt-section">
                                            <h3 class="kt-section__title kt-margin-b-20">
                                                Book As <span class="kt-badge kt-badge--danger kt-badge--dot"></span>
                                            </h3>
                                            <div class="kt-section__content">
                                                <div class="form-group form-group-last">
                                                    <div class="row">
                                                        <div class="col-lg-6">
                                            <label class="kt-option">
                                          <span class="kt-option__control">
                                          <span class="kt-radio kt-radio--state-brand">
                                          <input type="radio" name="book_as" class="type" value="1" checked="" <?php echo e((old('book_as')==1)?'checked':''); ?>>
                                          <span></span>
                                          </span>
                                          </span>
                                              <span class="kt-option__label">
                                          <span class="kt-option__head">
                                          <span class="kt-option__title">
                                            Sender
                                          </span>
                                          <span class="kt-option__focus"></span>
                                          </span>
                                          <span class="kt-option__body">
                                            For sending a parcel
                                          </span>
                                          </span>
                                                            </label>
                                                        </div>
                                                        <div class="col-lg-6">
                                                            <label class="kt-option">
                                          <span class="kt-option__control">
                                          <span class="kt-radio kt-radio--state-brand">
                                          <input type="radio" name="book_as" class="type" value="2"  <?php echo e((old('book_as')==2)?'checked':''); ?>>
                                          <span></span>
                                          </span>
                                          </span>
                                                                <span class="kt-option__label">
                                          <span class="kt-option__head">
                                          <span class="kt-option__title">
                                          Receiver
                                          </span>
                                          <span class="kt-option__focus"></span>
                                          </span>
                                          <span class="kt-option__body">
                                          For receiving shipment
                                          </span>
                                          </span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="form-text text-muted">
                                                        <!--must use this helper element to display error message for the options-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="kt-separator kt-separator--border-dashed kt-separator--space-lg kt-separator--portlet-fit kt-margin-t-0"></div>
                                        <div class="row">
                                            <div class="form-group col-lg-6">
                                                <label>Shipping Date<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                <div class="input-group date">
                                                    <input type="date" class="form-control date" name="ship_date" value="<?php echo e(old('ship_date')); ?>" required>
                                                    <div class="input-group-append">



                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group col-lg-6">
                                                <label>Shipping Time <span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                <div class="input-group ">
                                                    <input type="time" class="form-control ship_time" name="ship_time" value="<?php echo e(old('ship_time')); ?>"  required>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <h3 class="kt-section__title kt-margin-b-5 pt-1">
                                                            Delivery Type <span class="kt-badge  "></span>
                                                        </h3>
                                                        <label class="kt-option">
                                       <span class="kt-option__control">
                                       <span class="kt-radio kt-radio--state-brand">
                                       <input type="radio" name="dilivery_type" class="dilivery_typ" value="1"  checked="" <?php echo e((old('dilivery_type')==1)?'checked':''); ?>  >
                                       <span></span>
                                       </span>
                                       </span>
                                                            <span class="kt-option__label">
                                       <span class="kt-option__head">
                                       <span class="kt-option__title">
                                       Vehicle
                                       </span>
                                       <span class="kt-option__focus"></span>
                                       </span>
                                       <span class="kt-option__body">
                                       </span>
                                       </span>
                                                        </label>
                                                    </div>
                                    <div class="col-lg-6">
                                        <h3 class="kt-section__title kt-margin-b-5 pt-1">
                                            &nbsp;<span class=""></span>
                                        </h3>
                                        <label class="kt-option">
                                       <span class="kt-option__control">
                                       <span class="kt-radio kt-radio--state-brand">
                                       <input type="radio" name="dilivery_type" class="dilivery_typ" value="2" <?php echo e((old('dilivery_type')==2)?'checked':''); ?> >
                                       <span></span>
                                       </span>
                                       </span>
                                                            <span class="kt-option__label">
                                       <span class="kt-option__head">
                                       <span class="kt-option__title">
                                       Package
                                       </span>
                                       <span class="kt-option__focus"></span>
                                       </span>
                                       <span class="kt-option__body">
                                       </span>
                                       </span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                    <h3 class="kt-section__title kt-margin-b-5 pt-1 ">
                                                        Wants to avail Insurance? <span class="kt-badge  "></span>
                                                    </h3>
                                        <label class="kt-option">
                                       <span class="kt-option__control">
                                       <span class="kt-radio kt-radio--state-brand">
                                       <input type="radio" name="is_insured" class="is_insured" value="1" <?php echo e((old('is_insured')==1)?'checked':''); ?>>
                                       <span></span>
                                       </span>
                                       </span>
                                    <span class="kt-option__label">
                                       <span class="kt-option__head">
                                       <span class="kt-option__title">
                                       Yes
                                       </span>
                                       <span class="kt-option__focus"></span>
                                       </span>
                                       <span class="kt-option__body">
                                       </span>
                                       </span>
                                         </label>
                                                    </div>
                                    <div class="col-lg-6">
                                        <h3 class="kt-section__title kt-margin-b-5 pt-1">
                                            &nbsp;<span class=""></span>
                                        </h3>
                                        <label class="kt-option">
                                       <span class="kt-option__control">
                                       <span class="kt-radio kt-radio--state-brand">
                                       <input type="radio" name="is_insured" class="is_insured" value="0" checked="" <?php echo e((old('is_insured')==0)?'checked':''); ?>>
                                       <span></span>
                                       </span>
                                       </span>
                                          <span class="kt-option__label">
                                       <span class="kt-option__head">
                                       <span class="kt-option__title">
                                       No
                                       </span>
                                       <span class="kt-option__focus"></span>
                                       </span>
                                       <span class="kt-option__body">
                                       </span>
                                       </span>
                                                        </label>
                                                    </div>

                                            <div class="col-lg-12 packege-cost" style="display: none">
                                                <label>package Cost </label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend"><span class="input-group-text">package price</span></div>
                                                    <input type="number" class="form-control budget_client"  value="<?php echo e(old('package_cost')); ?>" name="package_cost" min="1" placeholder="Price">
                                                </div>
                                            </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="kt-portlet kt-portlet--mobile">
                            <div class="panel-heading">
                                <div class="kt-portlet__head panel-title" data-toggle="collapse" data-target="#collapseTwo">
                                    <div class="kt-portlet__head-label">
                                        <h3 class="kt-portlet__head-title">
                                            Sender information
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div id="collapseTwo" class="panel-collapse collapse">
                                <div class="kt-portlet__body">













                                    <div class="base_sender ">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Sender<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                    <div class="dropdown bootstrap-select form-control sender_address_id">
                                                        <select class="form-control" onchange="showsenderform1(this.value)" name="sender_name" id="sendr" data-live-search="true" title="Choose User" tabindex="-98">
                                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($sender->id); ?>" <?php echo e((old('sender_name')==$sender->id)?'selected':''); ?> <?php echo e((auth()->user()->id==$sender->id)?"selected":''); ?> ><?php echo e($sender->name); ?> (<?php echo e($sender->email); ?>)</option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="new" data-icon="flaticon2-add">Add New</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Sender Address/Client Address<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                    <div class="dropdown bootstrap-select form-control ">
                                                        <select class="form-control sender_address" placeholder=" Address" onchange="showsenderform(this.value)" name="sender_address" id="sender_address_id" data-live-search="true" title="Sender address"  tabindex="-98">
                                                            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($address->id); ?>" <?php echo e((old('sender_address')==$address->id)?'selected':''); ?> <?php echo e(($address->is_default==1)?'selected':''); ?> ><?php echo e($address->address); ?> </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="new" data-icon="flaticon2-add">Add New</option>
                                                        </select>
                                                        <input type="hidden" id="addris_id">

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-10 offset-1 p-1 d-none" id="addnewsenderaddress">
                                                <div class="kt-portlet kt-portlet--bordered kt-portlet--head--noborder kt-margin-b-0">
                                                    <div class="kt-portlet__head">
                                                        <div class="kt-portlet__head-label">
                                                            <span class="kt-portlet__head-icon">
                                                                <i class="flaticon2-user"></i>
                                                            </span>
                                                            <h3 class="kt-portlet__head-title">
                                                                Add a new sender address <small>Fill data and save it before you continue</small>
                                                            </h3>
                                                        </div>
                                                    </div>
                                                    <div class="kt-portlet__body">
                                                        <div class="location-senderaddress">
                                                            <div class="row">
                                                                <div class="form-group col-lg-4">
                                                                    <label>Sender addres</label>
                                                                    <input type="text" id="address-input" class="form-control map-input" autocomplete="off" placeholder="Enter Location">
                                                                    <input type="hidden" name="address_latitude" id="address-latitude" value="0" />
                                                                    <input type="hidden" name="address_longitude" id="address-longitude" value="0" />
                                                                </div>
                                                                <div class="form-group col-lg-4">
                                                                    <label>Country<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                                    <select class="form-control country_id" id="contry" onchange="getStates(this.value,'stat')" data-senderaddress="country"  title="Please choose country" data-live-search="true" name="senderaddress[country]" >
                                                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option  value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>


                                                                <div class="form-group col-lg-4">
                                                                    <label>State / Region&nbsp;<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                                    <select class="form-control state_id" id="stat" onchange="getCities(this.value,'cite')" data-senderaddress="administrative_area_level_1" title="Please select country first" name="senderaddress[state]" data-live-search="true" >
                                                                    </select>
                                                                </div>
                                                                <div class="form-group col-lg-4">
                                                                    <label>City&nbsp;<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                                    <select class="form-control city_id"  id="cite" onchange="getArea(this.value,'areea')" data-senderaddress="locality" name="senderaddress[city]" title="Please select state first" data-live-search="true" >
                                                                    </select>
                                                                </div>
                                                                <div class="form-group col-lg-4">
                                                                    <label>Area</label>
                                                                    <select class="form-control area_id"  id="areea" data-senderaddress="sublocality" name="senderaddress[county]" title="Please select city first" data-live-search="true" >
                                                                        <option data-hidden="true"></option>
                                                                    </select>
                                                                </div>

                                                                <div class="form-group col-lg-4">
                                                                    <label>Zip Code</label>
                                                                    <input class="form-control" type="text" id="zep" name="senderaddress[postal_code]" placeholder="zip code" >
                                                                </div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="form-group col-lg-12">
                                                                    <label>Google Map</label>
                                                                    <div id="address-map-container" style="width:100%;height:400px; ">
                                                                        <div style="width: 100%; height: 100%" id="address-map"></div>
                                                                    </div>
                                                                    <span class="form-text text-muted">Drag the pin to select the right location</span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="kt-portlet__foot">
                                                        <div class="row align-items-center">
                                                            <div class="col-lg-12">
                                                                <button type="button" onclick="saveaddress()" class="btn btn-success saved">Save <i class=" loadr bx bx-loader-circle bx-spin bx-rotate-90 d-none" style="color:#ffffff ; padding: 0; vertical-align: auto;font-size: 24px;"></i></button>
                                                                <button type="button" class="btn btn-secondary cancel">Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-10 offset-1 d-none p-1" id="addnewsender">
                                                <div class="kt-portlet kt-portlet--bordered kt-portlet--head--noborder kt-margin-b-0">
                                                    <div class="kt-portlet__head">
                                                        <div class="kt-portlet__head-label">
                                                   <span class="kt-portlet__head-icon">
                                                       <i class="flaticon2-user"></i>
                                                   </span>
                                                            <h3 class="kt-portlet__head-title">
                                                                Add new user <small>Fill data and save it before you can continue</small>
                                                            </h3>
                                                        </div>
                                                    </div>
                                                    <div class="kt-portlet__body">
                                                        <div class="row">
                                                            <div class="form-group col-lg-5">
                                                                <label>Name<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                                <input type="text" class="form-control name" name="receiver_name" id="s_nam" placeholder="Full name" >
                                                            </div>
                                                            <div class="form-group col-lg-5">
                                                                <label>Email<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                                <input class="form-control mobile" name="receiver[email]" id="s_email" type="email" placeholder="Email" >
                                                            </div>
                                                            <div class="form-group col-lg-5">
                                                                <label>Mobile<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                                <input type="number" class="form-control mobile" name="receiver[mobile]"  id="s_phone" placeholder="Number" >
                                                            </div>
                                                            <div class="form-group col-lg-5">
                                                                <label>Password<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                                <input type="password" class="form-control " name="receiver[pwd]" id="s_pass"  placeholder="Password">
                                                            </div>

                                                        </div>
                                                        <div class="location-receiver">
































































                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="kt-portlet__foot">
                                                        <div class="row align-items-center">
                                                            <div class="col-lg-12">
                                                                <button type="button" class="btn btn-success savee" onclick="sender_save()" >Save <i class='bx bx-loader-circle bx-spin bx-rotate-90 d-none' style='color:#ffffff ; padding: 0; vertical-align: auto;font-size: 24px;' ></i></button>
                                                                <button type="button" class="btn btn-secondary cancel">Cancel</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="kt-separator kt-separator--border-dashed kt-separator--space-lg kt-separator--portlet-fit"></div>
                                    <div class="form-group row">
                                        <label class="col-xl-3 col-lg-3 col-form-label">Payment Type&nbsp;<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                        <div class="col-lg-9 col-xl-6">
                                            <div class="dropdown bootstrap-select form-control">
                                                <select class="form-control" name="payment_type" id="payment_type"  tabindex="-98">
                                                    <option data-hidden="true"></option>
                                                    <option value="1"  <?php echo e((old('payment_type')==1)?'selected':''); ?> selected>Postpaid </option>
                                                    <option value="2" <?php echo e((old('payment_type')==2)?'selected':''); ?> >Prepaid </option>
                                                </select>
                                                <div class="dropdown-menu ">
                                                    <div class="inner show" role="listbox" id="bs-select-11" tabindex="-1">
                                                        <ul class="dropdown-menu inner show" role="presentation"></ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row type_1">
                                        <label class="col-xl-3 col-lg-3 col-form-label">Record receiver information ?&nbsp;<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                        <div class="col-lg-9 col-xl-6">
                                            <div class="kt-radio-inline">
                                                <label class="kt-radio">
                                                    <input type="radio"  <?php echo e((old('show_receiver_info')==1)?'checked':''); ?> name="show_receiver_info" class="show_receiver_info" value="1" checked="" > Yes
                                                    <span></span>
                                                </label>
                                                <label class="kt-radio">
                                                    <input type="radio" <?php echo e((old('show_receiver_info')==2)?'checked':''); ?> name="show_receiver_info" class="show_receiver_info" value="2" > No
                                                    <span></span>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="type_2 receiver_information">
                            <div class="kt-portlet kt-portlet--mobile">
                                <div class="panel panel-heading">
                                    <div class="kt-portlet__head panel-title" data-toggle="collapse" data-target="#collapseThree">
                                        <div class="kt-portlet__head-label">
                                            <h3 class="kt-portlet__head-title">
                                                Receiver information
                                            </h3>
                                        </div>
                                    </div>
                                </div>
                                <div id="collapseThree" class="panel-collapse collapse">
                                    <div class="kt-portlet__body">
                                        <div class="row m-0">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Client<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                    <div class="dropdown bootstrap-select form-control ">
                                                        <select onchange="showreceiverform1(this.value)" class="form-control" name="receiver_name" id="receiver_name" data-live-search="true" title="Client"  tabindex="-98">
                                                            <option data-hidden="true"></option>
                                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receiver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($receiver->id); ?>" <?php echo e((old('receiver_name')==$receiver->id)?'selected':''); ?>><?php echo e($receiver->name); ?> (<?php echo e($receiver->email); ?>)</option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="new" data-icon="flaticon2-add">Add New</option>
                                                        </select>

                                                    </div>
                                                </div>

                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group ">
                                                    <label>Receiver Address<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                    <div class="dropdown bootstrap-select form-control ">
                                                        <select onchange="showreceiverform(this.value)" class="form-control receiver_address_id" id="receiver_address_id" name="receiver_address"  data-live-search="true" title="Address"  tabindex="-98">
                                                            <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($address->id); ?>" <?php echo e((old('receiver_address')==$address->id)?'selected':''); ?>><?php echo e($address->address); ?> </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="new" data-icon="flaticon2-add">Add New</option>
                                                        </select>
                                                        <div class="dropdown-menu ">
                                                            <div class="bs-searchbox"><input type="text" class="form-control" autocomplete="off" role="combobox" aria-label="Search" aria-controls="bs-select-13" aria-autocomplete="list"></div>
                                                            <div class="inner show" role="listbox" id="bs-select-13" tabindex="-1">
                                                                <ul class="dropdown-menu inner show" role="presentation"></ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>





                                        <div class="col-md-10 offset-1 d-none p-1" id="addnewreceivr">
                                            <div class="kt-portlet kt-portlet--bordered kt-portlet--head--noborder kt-margin-b-0">
                                                <div class="kt-portlet__head">
                                                    <div class="kt-portlet__head-label">
                                                            <span class="kt-portlet__head-icon">
                                                                <i class="flaticon2-user"></i>
                                                            </span>
                                                        <h3 class="kt-portlet__head-title">
                                                            Add a new receiver address <small>Fill data and save it before you continue</small>
                                                        </h3>
                                                    </div>
                                                </div>
                                                <div class="kt-portlet__body">
                                                    <div class="location-senderaddress">
                                                        <div class="row">
                                                            <div class="form-group col-lg-4">
                                                                <label>Location</label>
                                                                <input type="text" id="address_input" autocomplete="off" class="form-control imap-input" placeholder="Enter address" >
                                                                <input type="hidden" name="address_latitude" id="address-latitude1" value="0" />
                                                                <input type="hidden" name="address_longitude" id="address-longitude1" value="0" />





                                                            </div>
                                                            <div class="form-group col-lg-4">
                                                                <label>Country<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                                <select class="form-control country_id" id="r_contry" onchange="getStates(this.value,'r_stat')" data-senderaddress="country"  title="Please choose country" data-live-search="true" name="senderaddress[country]" >
                                                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option  value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>


                                                            <div class="form-group col-lg-4">
                                                                <label>State / Region&nbsp;<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                                <select class="form-control state_id" id="r_stat" onchange="getCities(this.value,'r_cite')" data-senderaddress="administrative_area_level_1" title="Please select country first" name="senderaddress[state]" data-live-search="true" >
                                                                </select>
                                                            </div>
                                                            <div class="form-group col-lg-4">
                                                                <label>City&nbsp;<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                                <select class="form-control city_id"  id="r_cite" onchange="getArea(this.value,'r_areea')" data-senderaddress="locality" name="senderaddress[city]" title="Please select state first" data-live-search="true" >
                                                                </select>
                                                            </div>
                                                            <div class="form-group col-lg-4">
                                                                <label>Area</label>
                                                                <select class="form-control area_id"  id="r_areea" data-senderaddress="sublocality" name="senderaddress[county]" title="Please select city first" data-live-search="true" >
                                                                    <option data-hidden="true"></option>
                                                                </select>
                                                            </div>

                                                            <div class="form-group col-lg-4">
                                                                <label>Zip Code</label>
                                                                <input class="form-control" type="text" id="r_zep" name="senderaddress[postal_code]" placeholder="zip code" >
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="form-group col-lg-12">
                                                                <label>Google Map</label>
                                                                <div  style="width:100%;height:400px; ">
                                                                    <div style="width: 100%; height: 100%" id="address-mapp"></div>
                                                                </div>

                                                                <span class="form-text text-muted">Drag the pin to select the right location</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="kt-portlet__foot">
                                                    <div class="row align-items-center">
                                                        <div class="col-lg-12">
                                                            <button type="button" onclick="saveaddresss()" class="btn btn-success saveed">Save <i class=" loadir bx bx-loader-circle bx-spin bx-rotate-90 d-none" style="color:#ffffff ; padding: 0; vertical-align: auto;font-size: 24px;"></i></button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>




                                        <div class="col-md-10 offset-1 d-none p-1" id="addnewreceiver">
                                            <div class="kt-portlet kt-portlet--bordered kt-portlet--head--noborder kt-margin-b-0">
                                                <div class="kt-portlet__head">
                                                    <div class="kt-portlet__head-label">
                                                   <span class="kt-portlet__head-icon">
                                                       <i class="flaticon2-user"></i>
                                                   </span>
                                                        <h3 class="kt-portlet__head-title">
                                                            Add new user <small>Fill data and save it before you can continue</small>
                                                        </h3>
                                                    </div>
                                                </div>
                                                <div class="kt-portlet__body">
                                                    <div class="row">
                                                        <div class="form-group col-lg-5">
                                                            <label>Name<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                            <input type="text" class="form-control name" name="receiver[name]" id="r_nam" placeholder="Full name" >
                                                        </div>
                                                        <div class="form-group col-lg-5">
                                                            <label>Email<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                            <input class="form-control mobile" name="receiver[email]" id="r_email" type="email" placeholder="Email" >
                                                        </div>
                                                        <div class="form-group col-lg-5">
                                                            <label>Mobile<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                            <input type="number" class="form-control mobile" name="receiver[mobile]"  id="r_phone" placeholder="Number" >
                                                        </div>
                                                        <div class="form-group col-lg-5">
                                                            <label>Password<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                            <input type="password" class="form-control " name="receiver[pwd]" id="r_pass"  placeholder="Password">
                                                        </div>

                                                    </div>
                                                    <div class="location-receiver"></div>
                                                </div>
                                                <div class="kt-portlet__foot">
                                                    <div class="row align-items-center">
                                                        <div class="col-lg-12">
                                                            <button type="button" class="btn btn-success saveee" onclick="receiver_save()" >Save <i class='bx bxy bx-loader-circle bx-spin bx-rotate-90 d-none' style='color:#ffffff ; padding: 0; vertical-align: auto;font-size: 24px;' ></i></button>
                                                            <button type="button" class="btn btn-secondary cancel">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        

                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        <div class="form-group row kt-hidden package_fee">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Package Cost&nbsp;<span class="kt-badge kt-badge--danger kt-badge--dot"></span>
                                                <br><span class="text-muted">Amount that will be returned to the sender from the receiver</span>
                                            </label>
                                            <div class="col-lg-9 col-xl-6">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                       <span class="input-group-text">
                                       $
                                       </span>
                                                    </div>
                                                    <input type="text" class="form-control decimal" data-type="currency" name="package_fee" >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row kt-hidden package_fee">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Return Shipment Cost&nbsp;<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                            <div class="col-lg-9 col-xl-6">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                       <span class="input-group-text">
                                       $
                                       </span>
                                                    </div>
                                                    <input type="text" class="form-control decimal" data-type="currency" name="return_courier_fee" id="return_courier_fee" value="40.00" >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row kt-hidden package_fee">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Return package fees responsiable&nbsp;<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                            <div class="col-lg-9 col-xl-6">
                                                <div class="kt-radio-inline">
                                                    <label class="kt-radio">
                                                        <input type="radio" name="return_package_fee" class="return_package_fee" value="1" checked="" > Receiver
                                                        <span></span>
                                                    </label>
                                                    <label class="kt-radio">
                                                        <input type="radio" name="return_package_fee" class="return_package_fee" value="2" > Sender
                                                        <span></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="kt-portlet">
                            <div class="panel panel-heading">
                                <div class="kt-portlet__head panel-title" data-toggle="collapse" data-target="#collapseTFour">
                                    <div class="kt-portlet__head-label">
                                        <h3 class="kt-portlet__head-title">
                                            Shipment Details
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div id="collapseTFour" class="panel-collapse collapse">
                                <div class="kt-portlet__body pt-1" >
                                    <div class="kt-section mb-0">
                                        <h3 class=" mb-1 mt-1">
                                            Package Content
                                        </h3>

                                        <div class="kt-section__content m-1">
                                            <div class="form-group form-group-last row" >
                                                <div class="pakg  pb-0 m-3">
                                                    <div class="form-group form-group-last row" >
                                                        <div data-repeater-list="items" class="col-lg-12">
                                                            <div data-repeater-item class="align-items-center">
                                                                <div class="form-group row">
                                                                    <div class="col-md-6">
                                                                        <div class="kt-form__group--inline">
                                                                            <div class="kt-form__label">
                                                                                <label>Package type:</label>
                                                                            </div>
                                                                            <div class="kt-form__control">

                                                                                <select class="form-control selectpicker" data-live-search="true" name="category_id[]" >
                                                                                    <option data-hidden="true">Choose package type</option>
                                                                                    <?php $__currentLoopData = $shipment_packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option value="<?php echo e($package->id); ?>"><?php echo e($package->name); ?></option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-6">
                                                                        <div class="kt-form__group--inline">
                                                                            <div class="kt-form__label">
                                                                                <label class="kt-label m-label--single">Description:</label>
                                                                            </div>
                                                                            <div class="kt-form__control">
                                                                                <input type="text" class="form-control" name="description[]"  placeholder="package description">
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-6">
                                                                        <div class="kt-form__group--inline">
                                                                            <div class="kt-form__label">
                                                                                <label class="kt-label m-label--single">Quantity:</label>
                                                                            </div>
                                                                            <div class="kt-form__control">
                                                                                <input type="text" class="form-control bootstrap-touchspin-vertical-btn" name="quantity[]"  placeholder="package quantity" >
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-6">
                                                                        <div class="kt-form__group--inline">
                                                                            <div class="kt-form__label">
                                                                                <label class="kt-label m-label--single">Weight:</label>
                                                                            </div>
                                                                            <div class="kt-form__control">
                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend"><span class="input-group-text">Kg</span></div>
                                                                                    <input type="text" class="form-control bootstrap-touchspin-vertical-btn sub_weight" name="weight[]"  placeholder="Weight" >
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-12">
                                                                        <div class="kt-form__group--inline">
                                                                            <div class="kt-form__label">
                                                                                <label class="kt-label m-label--single">Dimensions&nbsp;<i class="flaticon2-delivery-package"></i>&nbsp;[Length&nbsp;x&nbsp;Width&nbsp;x&nbsp;Height] (cm):</label>
                                                                            </div>
                                                                            <div class="kt-form__control">
                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend">
                                                                                <span class="input-group-text">
                                                                                    <input type="text" class="form-control form-control-sm bootstrap-touchspin-vertical-btn" name="length[]" style="max-width: 100px;" >
                                                                                </span>
                                                                                    </div>
                                                                                    <div class="input-group-prepend"><span class="input-group-text">x</span></div>
                                                                                    <div class="input-group-prepend">
                                                                                    <span class="input-group-text">
                                                                                        <input type="text" class="form-control form-control-sm bootstrap-touchspin-vertical-btn" name="width[]" style="max-width: 100px;" >
                                                                                    </span>
                                                                                    </div>
                                                                                    <div class="input-group-prepend"><span class="input-group-text">x</span></div>
                                                                                    <div class="input-group-append">
                                                                                    <span class="input-group-text">
                                                                                        <input type="text" class="form-control form-control-sm bootstrap-touchspin-vertical-btn" name="height[]" style="max-width: 100px;" >
                                                                                    </span>
                                                                                    </div>


                                                                                </div>
                                                                            </div>

                                                                    </div> </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="packagerepeatorText"></div>
                                        <span class="fa fa-plus text-warning pl-2" style="cursor: pointer" onclick="packagerepeator()"> Add more</span>
                                    </div>
                                    <div class="kt-separator kt-separator--border-dashed kt-separator--space-lg kt-separator--portlet-fit"></div>
                                    <div class="kt-section">
                                        <div class="kt-section__content">
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            <div class="row">
                                                <div class="form-group col-lg-6">
                                                    <label>Shipping Fee <span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                    <div class="input-group">
                                                        <div class="input-group-prepend">
                                          <span class="input-group-text">
                                          $
                                          </span>
                                                        </div>
                                                        <input type="text" class="form-control decimal" data-type="currency" name="shipping_fee" id="delivery_cost" value="<?php echo e(old('courier_fee',30)); ?>" >
                                                    </div>
                                                </div>
                                                <div class="form-group col-lg-6">
                                                    <label>Total Weight&nbsp;<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                    <div class="input-group">
                                                        <div class="input-group-prepend"><span class="input-group-text">Kg</span></div>
                                                        <input  type="text" class="form-control total_weight" name="total_weight" value="<?php echo e(old('total_weight')); ?>" placeholder="Packages total weight">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 sec5">
                    <div class="panel panel-default">
                        <div class="kt-portlet kt-portlet--mobile">
                            <div class="panel panel-heading">
                                <div class="kt-portlet__head panel-title" data-toggle="collapse" data-target="#collapseTFive">
                                    <div class="kt-portlet__head-label">
                                        <h3 class="kt-portlet__head-title">
                                            Vehicle Details
                                        </h3>
                                    </div>
                                </div>
                            </div>
                            <div id="collapseTFive" class="panel-collapse collapse">
                                <div class="kt-portlet__body">
                                    <div class="row">







                                        <div class="form-group col-lg-8 offset-2">
                                            <label>Upload invoice <span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                            <div class="input-group">
                                                <div class="input-group-prepend"><span class="input-group-text">Invoice Image</span></div>
                                                <input type="file" class="form-control budget_client" accept="image/png, image/gif, image/jpeg"  name="invoice_image" min="1" placeholder="package Value">
                                            </div>
                                        </div>
                                        <div class="form-group col-lg-10 offset-2 mb-0" >
                                            <label for="vehicle_category">Choose vehicle category <span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                        </div>
                                        <div class="form-group col-lg-8 offset-2">
                                            <div class="dropdown bootstrap-select form-control">
                                                <select class="form-control" onchange="getVehicles(this.value)" name="vehicle_type" id="vehicle_category" tabindex="-98">
                                                    <option data-hidden="true"></option>
                                                    <?php $__currentLoopData = $vehicle_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($type->id); ?>" <?php echo e((old('vehicle_type')==$type->id)?'selected':''); ?>><?php echo e($type->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <div class="dropdown-menu ">
                                                    <div class="inner show" role="listbox" id="bs-select-25" tabindex="-1">
                                                        <ul class="dropdown-menu inner show" role="presentation"></ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-lg-10 offset-2 mb-0">
                                            <label for="slectedTracks">Available Vehicles</label>
                                        </div>
                                        <div class="form-group col-lg-8 offset-2">
                                            <div class="dropdown bootstrap-select form-control ">
                                                <select name="vehicle" class="form-control" id="vehicle_category_list">
                                                    <option value="" selected="" disabled="">Choose Vehicle</option>
                                                </select>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="kt-portlet">
                        <div class="kt-portlet__foot">
                            <div class="row">
                                <div class="col-lg-9 offset-3">
                                    <input type="submit" class="btn btn-warning save w-50 text-center" value="Save"/>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCoM2N8BXBveNHlX96-EjCkpaQDd7mVrLI&libraries=places&callback=initialize&libraries=places" async></script>


    <script>
        <?php if(\Session::has('success')): ?>
        toastr.success('<?php echo \Session::get('success'); ?>', 'Created successfully');
        <?php endif; ?>

        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        toastr.warning('<?php echo e($error); ?>');
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        function getVehicles(id) {
            $.ajax({
                type: 'GET',
                url: "<?php echo e(route('getVehicles')); ?>",
                data: {'id': id},
                success: function (data) {
                    var html='';
                    html += "<option value='' selected disabled>Choose Vehicle</option>";
                    $.each(data.data,function (key,value) {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    });
                    $('#vehicle_category_list').empty().append(html);
                    $('#vehicle_category_list').selectpicker('refresh');
                }
            })
        }


        function showsenderform(val) {
            if(val=='new'){
                var sender_id=$('#sendr option:selected').val()
                if(sender_id=='' || sender_id=='new'){
                    toastr.warning("Please Choose user first");
                    return;
                }

                $('#addnewsender').addClass('d-none');
                $('#addnewsenderaddress').removeClass('d-none');
            }else{
                $('#addnewsenderaddress').addClass('d-none');
                $('#addnewsender').addClass('d-none');
            }
        }
        function showreceiverform(val) {
            if(val=='new'){

                var receiver_name=$('#receiver_name option:selected').val()
                if(receiver_name=='' || receiver_name=='new'){
                    toastr.warning("Please Choose receiver first");
                    return;
                }

                $('#addnewreceivr').removeClass('d-none')
                $('#addnewreceiver').addClass('d-none');
            }else{
                $('#addnewreceivr').addClass('d-none');
                $('#addnewreceiver').addClass('d-none');
            }
        }

        function showreceiverform1(val) {
            if (val == 'new') {
                $('#addnewreceivr').addClass('d-none');
                $('#addnewreceiver').removeClass('d-none');
            } else
            {
                $.ajax({
                    type: 'GET',
                    url: "<?php echo e(route('getUserAddress')); ?>",
                    data: {'id': val},
                    success: function (data) {
                        var html='';
                        html += "<option value='' selected disabled>Choose address</option>";
                        $.each(data.address,function (key,value) {
                            html += '<option value="'+value.id+'">'+value.address+'</option>';
                        });
                        html += "<option value='new' ><span class='fa fa-plus-circle'></span> Add New</option>";
                        $('#receiver_address_id').empty().append(html);
                        $('#receiver_address_id').selectpicker('refresh');
                    }
                })
                $('#addnewreceiver').addClass('d-none');
                $('#addnewreceivr').addClass('d-none');
            }
        }

        function showsenderform1(val) {
            if(val=='new'){
                $('#addnewsender').removeClass('d-none');
                $('#addnewsenderaddress').addClass('d-none');
            }else{
                $.ajax({
                    type: 'GET',
                    url: "<?php echo e(route('getUserAddress')); ?>",
                    data: {'id': val},
                    success: function (data) {
                        var html='';
                        html += "<option value='' selected disabled>Choose address</option>";
                        $.each(data.address,function (key,value) {
                            html += '<option value="'+value.id+'">'+value.address+'</option>';
                        });
                        html += "<option value='new'> <span class='fa fa-plus-circle'></span> Add New</option>";
                        $('#sender_address_id').empty().append(html);
                        $('#sender_address_id').selectpicker('refresh');
                    }
                })
                $('#addnewsender').addClass('d-none');
                $('#addnewsenderaddress').addClass('d-none');
            }
        }


        function getStates(id,clas) {
            $.ajax({
                type: 'GET',
                url: "<?php echo e(route('getStates')); ?>",
                data: {'id': id},
                success: function (data) {
                    var html='';
                    html += "<option value='' selected disabled>Choose State</option>";
                    $.each(data.states,function (key,value) {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    });
                    $('#'+clas).empty().append(html);
                    $('#'+clas).selectpicker('refresh');
                }
            })

        };
        function getCities(id,clas) {
            $.ajax({
                type: 'GET',
                url: "<?php echo e(route('getCities')); ?>",
                data: {'id': id},
                success: function (data) {
                    var html='';
                    html += "<option value='' selected disabled>Choose City</option>";
                    $.each(data.cities,function (key,value) {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    });
                    $('#'+clas).empty().append(html);
                    $('#'+clas).selectpicker('refresh');
                }
            })
        };
        function getArea(id,clas) {
            $.ajax({
                type: 'GET',
                url: "<?php echo e(route('getArea')); ?>",
                data: {'id': id},
                success: function (data) {
                    var html='';
                    html += "<option value='' selected disabled>Choose Area</option>";
                    $.each(data.cities,function (key,value) {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    });
                    $('#'+clas).empty().append(html);
                    $('#'+clas).selectpicker('refresh');
                }
            })
        }

        function sender_save() {
            var s_nam = $('#s_nam').val();
            var s_email = $('#s_email').val();
            var s_pass = $('#s_pass').val();
            // var s_country = $('#s_country option:selected').val();
            var s_phone = $('#s_phone').val();
            // var statees = $('#statees option:selected').val();
            // var cityy = $('#cityy option:selected').val();
            // var s_add = $('#s_add').val();
            // var areaa = $('#areaa').val();
            var s_zip = $('#postal').val();

            if (s_nam == '') {
                $('#s_nam').css('border', '1px solid #e00258');
                return;
            } else {
                $('#s_nam').css('border', '1px solid #e2e5ec');
            }
            if (s_email == '') {
                $('#s_email').css('border', '1px solid #e00258');
                return;
            } else {
                $('#s_email').css('border', '1px solid #e2e5ec');
            }
            if (s_phone == '' || s_phone.length < 4) {
                $('#s_phone').css('border', '1px solid #e00258');
                return;
            } else {
                $('#s_phone').css('border', '1px solid #e2e5ec');
            }
            if (s_pass == '' || s_pass.length < 4) {
                $('#s_pass').css('border', '1px solid #e00258');
                return;
            } else {
                $('#s_pass').css('border', '1px solid #e2e5ec');
            }
            // alert(s_add.length);
            // if (s_add == '' || s_add.length < 2) {
            //     // alert('ss')
            //     $('#s_add').css('border', '1px solid #e00258');
            //     return;
            // } else {
            //     $('#s_add').css('border', '1px solid #e2e5ec');
            // }
            // if (s_country == '') {
            //     // alert(s_country);
            //     toastr.warning("Fill country");
            //     // $('#s_country').css('border', '1px solid #e00258');
            //     return;
            // } else {
            //     $('#s_country').css('border', '1px solid #e2e5ec');
            // }

            // if (statees == '') {
            //     toastr.warning("Fill state");
            //     return;
            // } else {
            //     $('#statees').css('border', '1px solid #e2e5ec');
            // }
            // if (cityy == '') {
            //     toastr.warning("Fill City");
            //     return;
            // } else {
            //     $('#cityy').css('border', '1px solid #e2e5ec');
            // }
            // if (areaa == '') {
            //     toastr.warning("Fill area field");
            //     return;
            // } else {
            //     $('#areaa').css('border', '1px solid #e2e5ec');
            // }
            $('.savee').css('opacity','0.5');
            $('.bx-spin').removeClass('d-none');
            $.ajax({
                type: 'post',
                url: "<?php echo e(route('createUser')); ?>",
                data: {
                    'phone': s_phone,
                    'password': s_pass,
                    'email': s_email,
                    'full_name': s_nam,
                    'zip': s_zip,
                    'form':'sender'
                },
                success: function (data) {
                    $('.savee').css('opacity','1');
                    $('.bx-spin').addClass('d-none');
                    if(data.error) {
                        $.each(data.error, function (key, value) {
                            toastr.warning(value);
                        })
                    }
                    if(data.success){
                        var html='';
                        // html += '<option value="'+data.address_id+'" selected>'+s_add+' </option>';
                        var html1='';
                        html1 += '<option value="'+data.user_id+'" selected>'+s_nam+' </option>';
                        // $('#sender_address_id').prepend(html);
                        // $('#sender_address_id').selectpicker('refresh');
                        $('#addnewsender').addClass('d-none');
                        $('#sendr').prepend(html1);
                        $('#sendr').selectpicker('refresh');

                        $('#sendr').val(data.user_id);
                        $('#sendr').change();
                        // $('#sender_address_id').val(data.address_id);
                        // $('#sender_address_id').change();
                        toastr.success(data.success);
                    }
                }

            })
        }
        function receiver_save() {
            var s_nam = $('#r_nam').val();
            var s_email = $('#r_email').val();
            var s_pass = $('#r_pass').val();
            // var s_country = $('#r_country option:selected').val();
            var s_phone = $('#r_phone').val();
            // var statees = $('#r_statees option:selected').val();
            // var cityy = $('#r_cityy option:selected').val();
            // var s_add = $('#r_add').val();
            // var areaa = $('#r_areaa').val();
            var s_zip = $('#r_postal').val();

            if (s_nam == '') {
                $('#r_nam').css('border', '1px solid #e00258');
                return;
            } else {
                $('#r_nam').css('border', '1px solid #e2e5ec');
            }
            if (s_email == '') {
                $('#r_email').css('border', '1px solid #e00258');
                return;
            } else {
                $('#r_email').css('border', '1px solid #e2e5ec');
            }
            if (s_phone == '' || s_phone.length < 4) {
                $('#r_phone').css('border', '1px solid #e00258');
                return;
            } else {
                $('#r_phone').css('border', '1px solid #e2e5ec');
            }
            if (s_pass == '' || s_pass.length < 4) {
                $('#r_pass').css('border', '1px solid #e00258');
                return;
            } else {
                $('#r_pass').css('border', '1px solid #e2e5ec');
            }
            // alert(s_add.length);
            // if (s_add == '' || s_add.length < 2) {
            //     // alert('ss')
            //     $('#r_add').css('border', '1px solid #e00258');
            //     return;
            // } else {
            //     $('#r_add').css('border', '1px solid #e2e5ec');
            // }
            // if (s_country == '') {
            //     // alert(s_country);
            //     toastr.warning("Fill country");
            //     // $('#s_country').css('border', '1px solid #e00258');
            //     return;
            // } else {
            //     $('#r_country').css('border', '1px solid #e2e5ec');
            // }
            //
            // if (statees == '') {
            //     toastr.warning("Fill state");
            //     return;
            // } else {
            //     $('#r_statees').css('border', '1px solid #e2e5ec');
            // }
            // if (cityy == '') {
            //     toastr.warning("Fill City");
            //     return;
            // } else {
            //     $('#r_cityy').css('border', '1px solid #e2e5ec');
            // }
            // if (areaa == '') {
            //     toastr.warning("Fill area field");
            //     return;
            // } else {
            //     $('#r_areaa').css('border', '1px solid #e2e5ec');
            // }
            $('.saveee').css('opacity','0.5');
            $('.bxy').removeClass('d-none');
            $.ajax({
                type: 'post',
                url: "<?php echo e(route('createUser')); ?>",
                data: {
                    'phone': s_phone,
                    'password': s_pass,
                    'email': s_email,
                    'full_name': s_nam,
                    'zip': s_zip,
                    'form':'receiver'
                },
                success: function (data) {
                    $('.saveee').css('opacity','1');
                    $('.bxy').addClass('d-none');
                    if(data.error) {
                        $.each(data.error, function (key, value) {
                            toastr.warning(value);
                        })
                    }
                    if(data.success){
                        var html='';
                        // html += '<option value="'+data.address_id+'" selected>'+s_add+' </option>';
                        var html1='';
                        html1 += '<option value="'+data.user_id+'" selected>'+s_nam+' </option>';
                        // $('#receiver_address_id').prepend(html);
                        // $('#receiver_address_id').selectpicker('refresh');
                        $('#addnewreceiver').addClass('d-none');
                        $('#receiver_name').prepend(html1);
                        $('#receiver_name').selectpicker('refresh');

                        $('#receiver_name').val(data.user_id);
                        $('#receiver_name').change();
                        // $('#receiver_address_id').val(data.address_id);
                        // $('#receiver_address_id').change();
                        toastr.success(data.success);
                    }
                }
            })
        }
        function saveaddress() {
            var address = $('#address-input').val();
            var lng = $('#address-longitude').val();
            var lat = $('#address-latitude').val();
            var country = $('#contry option:selected').val();
            var zip = $('#zep').val();
            var state = $('#stat option:selected').val();
            var city = $('#cite option:selected').val();
            var area = $('#areea').val();
            var user_id = $('#sendr option:selected').val();

            if (address == '') {
                toastr.warning("Fill address field");
                return;
            }
            if (country == '' ) {
                toastr.warning("Fill country field");
                return;
            }
            if (state == '' ) {
                toastr.warning("Fill state field");
                return;
            }

            if (city == '') {
                toastr.warning("Fill city field");
                return;
            }
            if (zip == '' ) {
                $('#zep').css('border', '1px solid #e00258');
                return;
            }


            $('.saved').css('opacity','0.5');
            $('.loadr').removeClass('d-none');
            $.ajax({
                type: 'post',
                url: "<?php echo e(route('createSenderAddress')); ?>",
                data: {
                    'area': area,
                    'address': address,
                    'city': city,
                    'state': state,
                    'country': country,
                    'zip': zip,
                    'user_id': user_id,
                    'lat': lat,
                    'lng': lng,
                    'form': 'sender',
                },
                success: function (data) {
                    $('.saved').css('opacity','1');
                    $('.loadr').addClass('d-none');
                    if(data.error) {
                        $.each(data.error, function (key, value) {
                            toastr.warning(value);
                        })
                    }
                    if(data.success){
                        var html='';
                        html += '<option value="'+data.address_id+'" selected>'+address+' </option>';
                        $('#sender_address_id').prepend(html);
                        $('#sender_address_id').selectpicker('refresh');
                        $('#addnewsenderaddress').addClass('d-none');
                        $('#sender_address_id').val(data.address_id);
                        $('#sender_address_id').change();
                        toastr.success(data.success);
                    }
                }
            })
        }
        function saveaddresss() {
            var address = $('#address_input').val();
            var country = $('#r_contry option:selected').val();
            var zip = $('#r_zep').val();
            var state = $('#r_stat option:selected').val();
            var city = $('#r_cite option:selected').val();
            var area = $('#r_areea').val();
            var user_id = $('#receiver_name option:selected').val();
            var lat = $('#address-latitude1').val();
            var lng = $('#address-longitude1').val();

            if (address == '') {
                toastr.warning("Fill address field");
                return;
            }
            if (country == '' ) {
                toastr.warning("Fill country field");
                return;
            }
            if (state == '' ) {
                toastr.warning("Fill state field");
                return;
            }

            if (city == '') {
                toastr.warning("Fill city field");
                return;
            }
            if (zip == '' ) {
                $('#zep').css('border', '1px solid #e00258');
                return;
            }



            $('.saveed').css('opacity','0.5');
            $('.loadir').removeClass('d-none');
            $.ajax({
                type: 'post',
                url: "<?php echo e(route('createSenderAddress')); ?>",
                data: {
                    'area': area,
                    'address': address,
                    'city': city,
                    'state': state,
                    'country': country,
                    'zip': zip,
                    'user_id': user_id,
                    'lat': lat,
                    'lng': lng,
                    'form': 'receiver',
                },
                success: function (data) {
                    $('.saveed').css('opacity','1');
                    $('.loadir').addClass('d-none');
                    if(data.error) {
                        $.each(data.error, function (key, value) {
                            toastr.warning(value);
                        })
                    }
                    if(data.success){
                        var html='';
                        html += '<option value="'+data.address_id+'" selected>'+address+' </option>';
                        $('#receiver_address_id').prepend(html);
                        $('#receiver_address_id').selectpicker('refresh');
                        $('#addnewreceivr').addClass('d-none');
                        $('#receiver_address_id').val(data.address_id);
                        $('#receiver_address_id').change();
                        toastr.success(data.success);
                    }
                }

            })
        }


        function initialize() {
            $('#address_input').on('keyup', function(e) {
                var keyCode = e.keyCode || e.which;
                if (keyCode === 13) {
                    e.preventDefault();
                    return false;
                }

                const locationInputs = document.getElementsByClassName("imap-input");
                const autocompletes = [];
                const geocoder = new google.maps.Geocoder;
                for (let i = 0; i < locationInputs.length; i++) {
                    const input = locationInputs[i];
                    const fieldKey = input.id.replace("_input", "");
                    // alert(fieldKey);
                    const isEdit = document.getElementById(fieldKey + "-latitude1").value != '' && document.getElementById(fieldKey + "-longitude1").value != '';
                    const latitude = parseFloat(document.getElementById(fieldKey + "-latitude1").value) || -33.8688;
                    const longitude = parseFloat(document.getElementById(fieldKey + "-longitude1").value) || 151.2195;

                    const map = new google.maps.Map(document.getElementById(fieldKey + '-mapp'), {
                        center: {lat: latitude, lng: longitude},
                        zoom: 18
                    });

                    const marker = new google.maps.Marker({
                        map: map,
                        position: {lat: latitude, lng: longitude},
                        title: "Click to zoom",
                        draggable: true
                    });
                    marker.setVisible(isEdit);
                    const autocomplete = new google.maps.places.Autocomplete(input);
                    autocomplete.key = fieldKey;
                    autocompletes.push({input: input, map: map, marker: marker, autocomplete: autocomplete});
                }
                for (let i = 0; i < autocompletes.length; i++) {
                    const input = autocompletes[i].input;
                    const autocomplete = autocompletes[i].autocomplete;
                    const map = autocompletes[i].map;
                    const marker = autocompletes[i].marker;

                    google.maps.event.addListener(autocomplete, 'place_changed', function () {
                        marker.setVisible(false);
                        const place = autocomplete.getPlace();
                        geocoder.geocode({'placeId': place.place_id}, function (results, status) {
                            if (status === google.maps.GeocoderStatus.OK) {
                                const lat = results[0].geometry.location.lat();
                                const lng = results[0].geometry.location.lng();
                                $('#address-latitude1').val(lat);
                                $('#address-longitude1').val(lng);
                                setLocationCoordinates(autocomplete.key, lat, lng);
                            }
                        });

                        if (!place.geometry) {
                            window.alert("No details available for input: '" + place.name + "'");
                            input.value = "";
                            return;
                        }

                        if (place.geometry.viewport) {
                            map.fitBounds(place.geometry.viewport);
                        } else {
                            map.setCenter(place.geometry.location);
                            map.setZoom(17);
                        }
                        marker.setPosition(place.geometry.location);
                        marker.setVisible(true);

                    });

                    google.maps.event.addListener(marker, 'dragend', function() {
                        geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
                            if (status === google.maps.GeocoderStatus.OK) {
                                if (results[0]) {
                                    $('#address_input').val(results[0].formatted_address);
                                    $('#address-latitude1').val(marker.getPosition().lat());
                                    $('#address-longitude1').val(marker.getPosition().lng());
                                    console.log(marker.getPosition().lng());
                                    console.log(marker.getPosition().lat());
                                }
                            }
                        });
                    });
                }
             return;
            });


            $('#address-input').on('keyup', function(e) {
                // alert('dasda');
                var keyCode = e.keyCode || e.which;
                if (keyCode === 13) {
                    e.preventDefault();
                    return false;
                }
            });
            const locationInputs = document.getElementsByClassName("map-input");
            const autocompletes = [];
            const geocoder = new google.maps.Geocoder;
            for (let i = 0; i < locationInputs.length; i++) {
                const input = locationInputs[i];
                const fieldKey = input.id.replace("-input", "");
                const isEdit = document.getElementById(fieldKey + "-latitude").value != '' && document.getElementById(fieldKey + "-longitude").value != '';
                const latitude = parseFloat(document.getElementById(fieldKey + "-latitude").value) || -33.8688;
                const longitude = parseFloat(document.getElementById(fieldKey + "-longitude").value) || 151.2195;

                const map = new google.maps.Map(document.getElementById(fieldKey + '-map'), {
                    center: {lat: latitude, lng: longitude},
                    zoom: 18
                });

                const marker = new google.maps.Marker({
                    map: map,
                    position: {lat: latitude, lng: longitude},
                    title: "Click to zoom",
                    draggable: true
                });
                marker.setVisible(isEdit);
                const autocomplete = new google.maps.places.Autocomplete(input);
                autocomplete.key = fieldKey;
                autocompletes.push({input: input, map: map, marker: marker, autocomplete: autocomplete});
            }
            for (let i = 0; i < autocompletes.length; i++) {
                const input = autocompletes[i].input;
                const autocomplete = autocompletes[i].autocomplete;
                const map = autocompletes[i].map;
                const marker = autocompletes[i].marker;

                google.maps.event.addListener(autocomplete, 'place_changed', function () {
                    marker.setVisible(true);
                    const place = autocomplete.getPlace();
                    geocoder.geocode({'placeId': place.place_id}, function (results, status) {
                        if (status === google.maps.GeocoderStatus.OK) {
                            const lat = results[0].geometry.location.lat();
                            const lng = results[0].geometry.location.lng();
                            setLocationCoordinates(autocomplete.key, lat, lng);
                        }
                    });

                    if (!place.geometry) {
                        window.alert("No details available for input: '" + place.name + "'");
                        input.value = "";
                        return;
                    }

                    if (place.geometry.viewport) {
                        map.fitBounds(place.geometry.viewport);
                    } else {
                        map.setCenter(place.geometry.location);
                        map.setZoom(17);
                    }
                    marker.setPosition(place.geometry.location);
                    marker.setVisible(true);

                });

                google.maps.event.addListener(marker, 'dragend', function() {
                    geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
                        if (status === google.maps.GeocoderStatus.OK) {
                            if (results[0]) {
                                $('#address-input').val(results[0].formatted_address);
                                $('#address-latitude').val(marker.getPosition().lat());
                                $('#address-longitude').val(marker.getPosition().lng());

                                console.log(marker.getPosition().lng());
                                console.log(marker.getPosition().lat());
                            }
                        }
                    });
                });

            }

        }
        function setLocationCoordinates(key, lat, lng) {
            const latitudeField = document.getElementById(key + "-" + "latitude");
            const longitudeField = document.getElementById(key + "-" + "longitude");
            latitudeField.value = lat;
            longitudeField.value = lng;
        }

        $('.is_insured').on('click', function(e) {

       if($('.is_insured:checked').val()==1){
           $('.packege-cost').css('display','block')
       }else{
           $('.packege-cost').css('display','none')
       }
        });
        $('.type').on('click', function(e) {
            var val=$('#addris_id').val();
            if(val==''){
                $('#addris_id').val($('#sender_address_id option:selected').val());
               val= $('#sender_address_id option:selected').val();
            }
           if($('.type:checked').val()==1){
               $('#sendr').val(<?php echo e(auth()->user()->id); ?>);
               $('#sendr').selectpicker('refresh');

               $('#sender_address_id').val(val);
               $('#sender_address_id').selectpicker('refresh');

               $('#receiver_name').val('');
               $('#receiver_name').selectpicker('refresh');

               $('#receiver_address_id').val('');
               $('#receiver_address_id').selectpicker('refresh');
           }else{
               $('#sendr').val('');
               $('#sendr').selectpicker('refresh');

               $('#receiver_name').val(<?php echo e(auth()->user()->id); ?>);
               $('#receiver_name').selectpicker('refresh');

               $('#sender_address_id').val('');
               $('#sender_address_id').selectpicker('refresh');

               $('#receiver_address_id').val(val);
               $('#receiver_address_id').selectpicker('refresh');
           }
        });

        var i=0;
        function packagerepeator() {
        var text= `
                 <div class="kt-section__content m-1 div_${i}">
                                            <div class="form-group form-group-last row" >
                                                <div class="pakg  pb-0 m-3">
                                                    <div class="form-group form-group-last row" >
                                                        <div data-repeater-list="items" class="col-lg-12">
                                                            <div data-repeater-item class="align-items-center">
                                                                <div class="form-group row">
                                                                    <div class="col-md-6">
                                                                        <div class="kt-form__group--inline">
                                                                            <div class="kt-form__label">
                                                                                <label>Package type:</label>
                                                                            </div>
                                                                            <div class="kt-form__control">
                                                                                <select class="form-control"  name="category_id[]" >
                                                                                    <option data-hidden="true">Choose package type</option>
                                                                                    <?php $__currentLoopData = $shipment_packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                         <option value="<?php echo e($package->id); ?>"><?php echo e($package->name); ?></option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                        </div>

                                                                        <div class="col-md-6">
                                                                        <div class="kt-form__group--inline">
                                                                            <div class="kt-form__label">
                                                                                <label class="kt-label m-label--single">Description:</label>
                                                                            </div>
                                                                            <div class="kt-form__control">
                                                                                <input type="text" class="form-control" name="description[]"  placeholder="Package description">
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-6">
                                                                        <div class="kt-form__group--inline">
                                                                            <div class="kt-form__label">
                                                                                <label class="kt-label m-label--single">Quantity:</label>
                                                                            </div>
                                                                            <div class="kt-form__control">
                                                                                <input type="text" class="form-control bootstrap-touchspin-vertical-btn" name="quantity[]"  placeholder="package quantity" >
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-6">
                                                                        <div class="kt-form__group--inline">
                                                                            <div class="kt-form__label">
                                                                                <label class="kt-label m-label--single">Weight:</label>
                                                                            </div>
                                                                            <div class="kt-form__control">
                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend"><span class="input-group-text">Kg</span></div>
                                                                                    <input type="text" class="form-control bootstrap-touchspin-vertical-btn sub_weight" name="weight[]"  placeholder="Weight" >
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-md-12">
                                                                        <div class="kt-form__group--inline">
                                                                            <div class="kt-form__label">
                                                                                <label class="kt-label m-label--single">Dimensions&nbsp;<i class="flaticon2-delivery-package"></i>&nbsp;[Length&nbsp;x&nbsp;Width&nbsp;x&nbsp;Height] (cm):</label>
                                                                            </div>
                                                                            <div class="kt-form__control">
                                                                                <div class="input-group">
                                                                                    <div class="input-group-prepend">
                                                                                <span class="input-group-text">
                                                                                    <input type="text" class="form-control form-control-sm bootstrap-touchspin-vertical-btn" name="length[]" style="max-width: 100px;" >
                                                                                </span>
                                                                                    </div>
                                                                                    <div class="input-group-prepend"><span class="input-group-text">x</span></div>
                                                                                    <div class="input-group-prepend">
                                                                                    <span class="input-group-text">
                                                                                        <input type="text" class="form-control form-control-sm bootstrap-touchspin-vertical-btn" name="width[]" style="max-width: 100px;" >
                                                                                    </span>
                                                                                    </div>
                                                                                    <div class="input-group-prepend"><span class="input-group-text">x</span></div>
                                                                                    <div class="input-group-append">
                                                                                    <span class="input-group-text">
                                                                                        <input type="text" class="form-control form-control-sm bootstrap-touchspin-vertical-btn" name="height[]" style="max-width: 100px;" >
                                                                                    </span>
                                                                                    </div>


                                                                                   <span  style="cursor:pointer" onclick=minus('${i}') class='fa fa-times-circle pt-4 ml-3 text-danger'></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                         </div>

    </div>
</div>
</div>
</div>
</div>
</div>
</div>
`
            i++;
            $('.packagerepeatorText').append(text);

        }
        function minus(i) {
$('.div_'+i).hide();
        }



    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebilty-laravel\resources\views/user/shipment/add-shipment.blade.php ENDPATH**/ ?>