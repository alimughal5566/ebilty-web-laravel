<?php $__env->startSection('content'); ?>
    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
        <div class="kt-container  kt-container--fluid  ">
            <div class="kt-subheader__main">
                
                <span class="kt-subheader__separator kt-subheader__separator--v"></span>

                    
                    
                    
                    
                    
                    
                    
                    
                    <a href="#" class="kt-subheader__breadcrumbs-home">Profile</a>
                    <span class="kt-subheader__breadcrumbs-link kt-subheader__breadcrumbs-link--active"></span>
                </div>
            </div>
            <div class="kt-subheader__toolbar">
                <div class="kt-subheader__wrapper">
                </div>
            </div>
        </div>
    <div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
        <!--end:: Portlet-->
        <div class="row">
            <div class="col-xl-3">
                <!--begin:: Widgets/Order Statistics-->
                <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-portlet__head">
                        <div class="kt-portlet__head-label">
                            <h3 class="kt-portlet__head-title">
                            </h3>
                        </div>
                    </div>
                    <div class="kt-portlet__body kt-portlet__body--fluid ">
                        <div class="kt-widget12">
                            <div class="kt-widget12__content">
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info ">
                                        <span class="kt-widget12__desc d-inline-flex "><b>Profile Picture</b></span>
                                        <span class="fa <?php echo e(($user->documents_verified==1)?'fa-check-circle text-success':'fa-times-circle text-danger'); ?>"></span>
                                        <?php if(auth()->check() && auth()->user()->hasRole('customer')): ?>
                                        <?php if($user->id==auth()->user()->id): ?>
                                            <span data-toggle="modal" data-target="#updateProfilePic" title="Edit" class="text-right float-right fa fa-edit" style="cursor: pointer"></span>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if(auth()->check() && auth()->user()->hasRole('admin|driver|cracker|company')): ?>
                                             <?php if($user->edit_request==1 && $user->id==auth()->user()->id): ?>
                                                  <span data-toggle="modal" data-target="#updateProfilePic" title="Edit" class="text-right float-right fa fa-edit" style="cursor: pointer"></span>
                                             <?php endif; ?>
                                        <?php endif; ?>
                                        <?php $profile_image='/images/noimage.jpg'; ?>
                                        <?php if($user->profile_image): ?>
                                            <?php    $profile_image= '/images/profile/'.$user->profile_image; ?>
                                        <?php endif; ?>
                                        <span class="kt-widget12__value"><img src="<?php echo e(url($profile_image)); ?>"  alt="" width="300" ></span>
                                    </div>
                                </div>
                                <?php if(auth()->check() && auth()->user()->hasRole('admin|driver|cracker|company')): ?>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info ">
                                        <span class="kt-widget12__desc d-inline-flex "><b>License</b></span>
                                        <span class="fa <?php echo e(($user->documents_verified==1)?'fa-check-circle text-success':'fa-times-circle text-danger'); ?>"></span>

                                             <?php if($user->edit_request==1 && $user->id==auth()->user()->id): ?>
                                                  <span data-toggle="modal" data-target="#edit2" title="Edit" class="text-right float-right fa fa-edit" style="cursor: pointer"></span>
                                             <?php endif; ?>
                                        <?php $license='/images/noimage.jpg'; ?>
                                        <?php if($user->license_image): ?>
                                            <?php    $license= '/images/license/'.$user->license_image; ?>
                                        <?php endif; ?>
                                        <span class="kt-widget12__value"><img src="<?php echo e(url($license)); ?>"  alt="" width="300" ></span>
                                    </div>
                                </div>

                                <div class="kt-widget12__item">
                                        <div class="kt-widget12__info">
                                            <span class="kt-widget12__desc d-inline-flex"><b>Identity Card</b></span>
                                            <span class="fa <?php echo e(($user->documents_verified==1)?'fa-check-circle text-success':'fa-times-circle text-danger'); ?>"></span>

                                            <?php if( $user->edit_request==1 && $user->id==auth()->user()->id): ?>
                                               <span data-toggle="modal" data-target="#edit" title="Edit" class="text-right float-right fa fa-edit" style="cursor: pointer"></span>
                                             <?php endif; ?>
                                            <?php $cnic='/images/noimage.jpg'; ?>
                                            <?php if($user->cnic_image): ?>
                                                <?php  $cnic= '/setting/cnic/'.$user->cnic_image; ?>
                                            <?php endif; ?>
                                            <span class="kt-widget12__value">
                                                <img src="<?php echo e(url($cnic)); ?>"  alt="" width="300">
                                            </span>
                                        </div>
                                </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
                <!--end:: Widgets/Order Statistics-->
            </div>



            <div class="col-xl-9">
                <!--begin:: Widgets/Order Statistics-->
                <div class=" row col-xl-12">
                   <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-portlet__head ">
                        <div class="kt-portlet__head-label d-flex align-items-center">
                            <h3 class="kt-portlet__head-title">
                                Personal Details
                            </h3>
                        </div>





                        <div>
                                <?php if(auth()->check() && auth()->user()->hasRole('admin|driver|cracker|company')): ?>
                            <?php if($user->documents_verified==0): ?>
                                <h4 class="text-right float-right pt-3 pr-1 ">
                                    <span class="text-danger ml-2"> Not verified </span>
                                </h4>
                            <?php endif; ?>
                            <?php if($user->edit_request=='' && $user->edit_request!=3 && $user->id==auth()->user()->id): ?>
                                <span class="text-right float-right pt-4 ml-0">
                                    <a href="<?php echo e(route('requestToEdit')); ?>"> request to edit </a>
                                </span>
                            <?php endif; ?>
                            <?php if($user->edit_request==1 && $user->id==auth()->user()->id): ?>
                                <span data-toggle="modal" data-target="#edit3" title="Edit" class="text-right float-right fa fa-edit text-warning pt-4" style="cursor: pointer"></span>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('customer')): ?>
                                <?php if($user->id==auth()->user()->id): ?>
                                    <span data-toggle="modal" data-target="#edit3" title="Edit" class="text-right float-right fa fa-edit text-warning pt-4" style="cursor: pointer"></span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                    </div>
                    <div class="kt-portlet__body kt-portlet__body--fluid">
                        <div class="kt-widget12">
                            <div class="kt-widget12__content">
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Name</span>
                                        <span class="kt-widget12__value">
                                        <?php echo e(ucfirst($user->name)); ?>

                                                </span>
                                    </div>
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Email</span>
                                        <span class="kt-widget12__value"><?php echo e($user->email); ?></span>
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Phone</span>
                                        <span class="kt-widget12__value">
                                            <?php echo e($user->phone); ?>


                                     <span class=" btn-bold "></span></span>
                                   </div>

                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Registered date</span>
                                        <span class="kt-widget12__value">
                                            <?php echo e($user->created_at->format('d-M-Y')); ?>


                                     <span class=" btn-bold "></span></span>
                                   </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>



                <div class=" row col-xl-12">
                   <div class="kt-portlet kt-portlet--height-fluid">
                    <div class="kt-portlet__head ">
                        <div class="kt-portlet__head-label d-flex align-items-center">
                            <h3 class="kt-portlet__head-title">
                                Location Details
                            </h3>
                        </div>





                        <div>
                        <?php if(auth()->check() && auth()->user()->hasRole('customer')): ?>
                            <?php if($user->id==auth()->user()->id): ?>
                                <span data-toggle="modal" data-target="#edit6" title="Edit" class="text-right float-right fa fa-edit text-warning pt-4" style="cursor: pointer"></span>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(auth()->check() && auth()->user()->hasRole('admin|driver|cracker|company')): ?>
                            <?php if($user->edit_request==1 && $user->id==auth()->user()->id): ?>
                                <span data-toggle="modal" data-target="#edit6" title="Edit" class="text-right float-right fa fa-edit text-warning pt-4" style="cursor: pointer"></span>
                            <?php endif; ?>
                        <?php endif; ?>
                        </div>


                    </div>
                    <div class="kt-portlet__body kt-portlet__body--fluid">
                        <div class="kt-widget12">
                            <div class="kt-widget12__content">
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">Country</span>
                                        <span class="kt-widget12__value">
                                       <?php echo e(($user->country)?$user->country->name:'N/a'); ?>

                                                </span>
                                    </div>
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">State</span>
                                        <span class="kt-widget12__value"><?php echo e(($user->state)?$user->state->name:'N/a'); ?></span>
                                    </div>
                                </div>
                                <div class="kt-widget12__item">
                                    <div class="kt-widget12__info">
                                        <span class="kt-widget12__desc">City</span>
                                        <span class="kt-widget12__value">
                                            <?php echo e(($user->city)?$user->city->name:'N/a'); ?>

                                            
                                     <span class=" btn-bold "></span></span>
                                   </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                </div>
                <!--end:: Widgets/Order Statistics-->
            </div>


        </div>



    </div>


    <div class="modal fade show" id="edit2" tabindex="-1" role="dialog" aria-labelledby="exampleModalSizeSm"  aria-modal="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Upload license</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i aria-hidden="true" class="ki ki-close"></i>
                    </button>
                </div>
          <form method="POST" action="<?php echo e(route('updateLicense')); ?>" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="card card-custom">
                        <div class="card-body p-0">
                            <div class="row justify-content-center pl-4 p-1 px-md-0">
                                <div class="col-md-12">
                                    <div class="form-group row pl-4">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-md-12 mt-3 ">
                                                    
                                                </div>

                                                <div class="col-lg-11">
                                                    <div class="form-check">
                                                        <label>License Number:</label>
                                                        <input name="license_number" value="<?php echo e($user->license_number); ?>" class="form-control" type="text" required/>

                                                    </div>
                                                </div>
                                                <div class="col-lg-11">
                                                    <div class="form-check">
                                                        <label>License Picture:</label>
                                                        <input name="license_image" class="form-control"  type="file" accept="image/*" required/>
                                                    </div>
                                                </div>

                                            </div>

                                    </div>

                                </div>

                                <!--end::Invoice-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="submit" value="Update" class="btn btn-sm btn-warning">
                    <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">back
                    </button>
                </div>
              </form>
            </div>
        </div>
    </div>
    <div class="modal fade show" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalSizeSm"  aria-modal="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Cnic details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i aria-hidden="true" class="ki ki-close"></i>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('updateCnic')); ?>" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="card card-custom">
                            <div class="card-body p-0">
                                <div class="row justify-content-center pl-4 p-1 px-md-0">
                                    <div class="col-md-12">
                                        <div class="form-group row pl-4">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-md-12 mt-3 ">
                                                    
                                                </div>

                                                <div class="col-lg-11">
                                                    <div class="form-check">
                                                        <label>Cnic Number:</label>
                                                        <input name="cnic_number" value="<?php echo e($user->cnic_number); ?>" class="form-control" type="text" required/>

                                                    </div>
                                                </div>
                                                <div class="col-lg-11">
                                                    <div class="form-check">
                                                        <label>Cnic Picture:</label>
                                                        <input name="cnic_image" class="form-control"  type="file" accept="image/*" required/>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <!--end::Invoice-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" value="Update" class="btn btn-sm btn-warning">
                        <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">back
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <div class="modal fade show" id="edit3" tabindex="-1" role="dialog" aria-labelledby="exampleModalSizeSm"  aria-modal="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Profile details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i aria-hidden="true" class="ki ki-close"></i>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('updatePersonalInfo')); ?>"  enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="card card-custom">
                            <div class="card-body p-0">
                                <div class="row justify-content-center pl-4 p-1 px-md-0">
                                    <div class="col-md-12">
                                        <div class="form-group row pl-4">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-md-12 mt-3 ">
                                                    
                                                </div>

                                                <div class="col-lg-11">
                                                    <div class="form-check">
                                                        <label>Name:</label>
                                                        <input name="nam" value="<?php echo e($user->name); ?>" class="form-control" type="text" required/>

                                                    </div>
                                                </div>
                                                <div class="col-lg-11">
                                                    <div class="form-check">
                                                        <label>Phone:</label>
                                                        <input name="phone" class="form-control"  value="<?php echo e($user->phone); ?>" type="text"  required/>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <!--end::Invoice-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" value="Update" class="btn btn-sm btn-warning">
                        <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">back
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>


    <div class="modal fade show" id="edit6" tabindex="-1" role="dialog" aria-labelledby="exampleModalSizeSm"  aria-modal="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Location details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i aria-hidden="true" class="ki ki-close"></i>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('updateLocationInfo')); ?>"  enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="card card-custom">
                            <div class="card-body p-0">
                                <div class="row justify-content-center pl-4 p-1 px-md-0">
                                    <div class="col-md-12">
                                        <div class="form-group row pl-4">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-lg-11 pt-3">
                                                    <div class="form-check">
                                                        <label>Country:</label>


                                                        <select class="form-control country_id" id="contry" onchange="getStates(this.value,'stat')" required title="Please choose country" data-live-search="true" name="country_id" >
                                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($country->id); ?>" <?php echo e(($user->country && $user->country->id==$country->id)?'selected':''); ?>><?php echo e($country->name); ?>

                                                            </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-11 pt-3">
                                                    <div class="form-check">
                                                        <label>State:</label>
                                                            <label>State / Region&nbsp;<span class="kt-badge kt-badge--danger kt-badge--dot"></span></label>
                                                            <select class="form-control state_id" id="stat" onchange="getCities(this.value,'cite')"  title="Please choose state" name="state_id" data-live-search="true" required  >
                                                               <?php if($user->state): ?>
                                                                    <option value="<?php echo e($user->state->id); ?>" selected><?php echo e($user->state->name); ?>

                                                                <?php endif; ?>
                                                            </select>

                                                    </div>
                                                </div>
                                                <div class="col-lg-11 pt-3">
                                                    <div class="form-check">
                                                        <label>City:</label>
                                                        <select class="form-control city_id" name="city_id" id="cite" title="Please choose city" data-live-search="true" required>
                                                            <?php if($user->city): ?>
                                                                <option value="<?php echo e($user->city->id); ?>" selected><?php echo e($user->city->name); ?>

                                                            <?php endif; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <!--end::Invoice-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" value="Update" class="btn btn-sm btn-warning">
                        <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">back
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade show" id="updateProfilePic" tabindex="-1" role="dialog" aria-labelledby="exampleModalSizeSm"  aria-modal="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Profile Picture</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i aria-hidden="true" class="ki ki-close"></i>
                    </button>
                </div>
                <form method="POST" action="<?php echo e(route('updateProfilePic')); ?>" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="card card-custom">
                            <div class="card-body p-0">
                                <div class="row justify-content-center pl-4 p-1 px-md-0">
                                    <div class="col-md-12">
                                        <div class="form-group row pl-4">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-md-12 mt-3 ">
                                             </div>

                                                <div class="col-lg-11">
                                                    <div class="form-check">
                                                        <label>Profile picture:</label>
                                                        <input name="profile_image" class="form-control"  value="<?php echo e($user->profile_picture); ?>" type="file" accept="image/*"  required/>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                    <!--end::Invoice-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" value="Update" class="btn btn-sm btn-warning">
                        <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">back
                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous"></script>

    <script>
        <?php if(\Session::has('success')): ?>
           toastr.success('<?php echo \Session::get('success'); ?>');
        <?php endif; ?>


        function getStates(id,clas) {
            $.ajax({
                type: 'GET',
                url: "<?php echo e(route('getStates')); ?>",
                data: {'id': id},
                success: function (data) {
                    var html='';
                    html += "<option value='' selected disabled>Choose State</option>";
                    $.each(data.states,function (key,value) {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    });
                    $('#'+clas).empty().append(html);
                    $('#'+clas).selectpicker('refresh');
                }
            })

        }

        function getCities(id,clas) {
            $.ajax({
                type: 'GET',
                url: "<?php echo e(route('getCities')); ?>",
                data: {'id': id},
                success: function (data) {
                    var html='';
                    html += "<option value='' selected disabled>Choose City</option>";
                    $.each(data.cities,function (key,value) {
                        html += '<option value="'+value.id+'">'+value.name+'</option>';
                    });
                    $('#'+clas).empty().append(html);
                    $('#'+clas).selectpicker('refresh');
                }
            })
        }





        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebilty-laravel\resources\views/user/profile/show.blade.php ENDPATH**/ ?>