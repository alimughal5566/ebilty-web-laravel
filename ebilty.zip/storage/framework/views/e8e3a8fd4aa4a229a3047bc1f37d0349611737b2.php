<head>
  <title><?php echo $__env->yieldContent('title','Ebilty'); ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="<?php echo e(asset('js')); ?>/jquery.min.js"></script>
  <link rel="stylesheet" href="<?php echo e(asset('css')); ?>/bootstrap.min.css">
  <script src="<?php echo e(asset('js')); ?>/jquery.min.js"></script>
  <script src="<?php echo e(asset('js')); ?>/popper.min.js"></script>
  <script src="<?php echo e(asset('js')); ?>/bootstrap.min.js"></script>
  <link rel="stylesheet" href="<?php echo e(asset('css')); ?>/all.css"/>
  <link rel="stylesheet" href="<?php echo e(asset('css')); ?>/line-awesome.min.css">
    <link rel="icon" href="<?php echo e(url('/uploads/logos/favicon.png')); ?>">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('css')); ?>/bootstrap-select.min.css">
  <!-- Latest compiled and minified JavaScript -->
  <script src="<?php echo e(asset('js')); ?>/bootstrap-select.min.js"></script>
    <script src="<?php echo e(asset('js')); ?>/boxicons.js"></script>
    <link href='<?php echo e(asset('css')); ?>/boxicons.min.css' rel='stylesheet'>

  <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom_style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/light.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendors.bundle.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/ns-default.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/ns-style-other.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.bundle.css')); ?>">
</head>


























<?php /**PATH C:\xampp\htdocs\ebilty-laravel\resources\views/admin/layout/head.blade.php ENDPATH**/ ?>