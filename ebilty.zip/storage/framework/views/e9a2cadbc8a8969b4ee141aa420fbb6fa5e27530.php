<?php $__env->startSection('content'); ?>
    
    <style>
        .progress {
            width: 90px;
            height: 90px;
            background: none;
            position: relative;
        }
        .progress::after {
            content: "";
            width: 100%;
            height: 100%;
            border-radius: 50%;
            border: 6px solid #eee;
            position: absolute;
            top: 0;
            left: 0;
        }

        .progress>span {
            width: 50%;
            height: 100%;
            overflow: hidden;
            position: absolute;
            top: 0;
            z-index: 1;
        }

        .progress .progress-left {
            left: 0;
        }

        .progress .progress-bar {
            width: 100%;
            height: 100%;
            background: none;
            border-width: 6px;
            border-style: solid;
            position: absolute;
            top: 0;
        }

        .progress .progress-left .progress-bar {
            left: 100%;
            border-top-right-radius: 80px;
            border-bottom-right-radius: 80px;
            border-left: 0;
            -webkit-transform-origin: center left;
            transform-origin: center left;
        }

        .progress .progress-right {
            right: 0;
        }

        .progress .progress-right .progress-bar {
            left: -100%;
            border-top-left-radius: 80px;
            border-bottom-left-radius: 80px;
            border-right: 0;
            -webkit-transform-origin: center right;
            transform-origin: center right;
        }

        .progress .progress-value {
            position: absolute;
            top: 0;
            left: 0;
        }

        /*
        *
        * ==========================================
        * FOR DEMO PURPOSE
        * ==========================================
        *
        */


        .rounded-lg {
            border-radius: 1rem;
        }

        .text-gray {
            color: #aaa;
        }

        div.h4 {
            line-height: 1rem;
        }

    </style>




    <div class="kt-subheader   kt-grid__item" id="kt_subheader">
        <div class="kt-container  kt-container--fluid  ">
            <div class="kt-subheader__main">
                
                <span class="kt-subheader__separator kt-subheader__separator--v"></span>
                <div class="kt-subheader__breadcrumbs">
                    
                    
                    
                    
                    
                    
                    
                    
                    <a href="#" class="kt-subheader__breadcrumbs-home">
                        Shipments</a>
                    <span class="kt-subheader__breadcrumbs-link kt-subheader__breadcrumbs-link--active"></span>
                </div>
            </div>
            <div class="kt-subheader__toolbar">
                <div class="kt-subheader__wrapper">
                </div>
            </div>
        </div>
    </div>
    <div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid bg-white">
        <table class="table table-fluid " style="font-size: initial" >
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">From</th>
                <th scope="col">To</th>
                <th scope="col">Shipment Time</th>
                <th scope="col">Status</th>
                <th scope="col"></th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><a href="<?php echo e(route('shipmentDetail',[$shipment->id])); ?>"><?php echo e($shipment->id); ?></a></th>
                    <td><?php echo e($shipment->sender->address); ?><small> (<?php echo e($shipment->sender->user->name); ?>)</small></td>
                    <td><?php echo e($shipment->receiver->address); ?><small> (<?php echo e($shipment->receiver->user->name); ?>)</small></td>
                    <td><?php echo e($shipment->ship_date); ?><br><?php echo e($shipment->ship_time); ?></td>
                    <td><?php echo e($shipment->status->name); ?></td>
                    <td>
                        <?php $percentage=0;
                        if($shipment->status_id==1){
                        $percentage=30;
                        }
                        if($shipment->status_id==6){
                        $percentage=20;
                        }
                        if($shipment->status_id==4){
                        $percentage=40;
                        }
                        if($shipment->status_id==6){
                        $percentage=35;
                        }
                        if($shipment->status_id==8){
                        $percentage=100;
                        }
                        if($shipment->status_id==7){
                        $percentage=90;
                        }
                        if($shipment->status_id==3){
                        $percentage=50;
                        }
                        ?>
                        <div class="progress mx-auto" data-value='<?php echo e($percentage); ?>'>
                              <span class="progress-left">
                                  <span class="progress-bar <?php echo e(($percentage<21)?'border-warning':(($percentage<51)?'border-info':(($percentage<81)?'border-danger':'border-success'))); ?>"></span>
                              </span>
                            <span class="progress-right">
                                                 <span class="progress-bar <?php echo e(($percentage<21)?'border-warning':(($percentage<51)?'border-info':(($percentage<81)?'border-danger':'border-success'))); ?>"></span>
                                          </span>
                            <div class="progress-value w-100 h-100 rounded-circle d-flex align-items-center justify-content-center">
                                <div class="h2 font-weight-bold"><?php echo e($percentage); ?><sup class="small">%</sup></div>
                            </div>
                        </div>
                    </td>

                    <td>
                        <?php if(count($shipment->bids)>0 ): ?>
                            <span class="example-tools justify-content-center">
                            <a class=" btn btn-sm btn-default btn-text-primary btn-hover-danger btn-icon" onclick="showBids('<?php echo e($shipment->bids); ?>')" data-toggle="modal" data-target="#myModal"   style="position: relative; cursor: pointer" aria-describedby="tooltip797420">
                                 <span class=" text-success" style=" position: absolute;top: -6px; right: -2px;">●</span>
                           <i class="la la-car"></i></a>
                       </span>
                        <?php else: ?>
                            <span class="example-tools justify-content-center">
                            <a class=" btn btn-sm btn-default btn-text-primary btn-hover-danger btn-icon"   data-target="#myModal" title=" 0 Bids"  style="position: relative; cursor: default" aria-describedby="tooltip797420">
                                 <span class=" text-danger" style=" position: absolute;top: -6px; right: -2px;">●</span>
                           <i class="la la-car"></i></a>
                       </span>
                        <?php endif; ?>

                    </td>

                </tr>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center p-1">No shippment found</td>
                </tr>
            <?php endif; ?>

            </tbody>
        </table>
        <div class="float-right mr-2">
            <?php echo e($shipments->links()); ?>

        </div>
    </div>


    
    
    

    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Bids</h4>
                    <button type="button" class="close" data-dismiss="modal"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="card-body  p-0">
                        <!--begin::Invoice-->
                        <div class="col-md-10 offset-1 ">
                            <table class="table" id="jqueryTable">
                                <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Applied at</th>
                                    <th>Verified</th>
                                    <th>Budget</th>
                                    <th>Bid Amount</th>
                                    <th>Route</th>
                                    <th>Last updated</th>
                                    <th style="min-width: 170px">Action</th>
                                </tr>
                                </thead>
                                <tbody id="bid_list"><tr>
                                </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>


            </div>
        </div>
    </div>

    <div class="modal fade" id="showreviseModal" tabindex="-1" style="background-color: #afafaf !important;" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Revision request</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div>
                        <lable for="bid_price">Amount to be revised
                            <input type="number" id="amt" name="bid_amt" class="form-control" min="1" placeholder="Revision amount" required>
                            <input type="hidden" id="bedid" name="bedid" >
                            <input type="hidden" id="rank" name="rank">
                        </lable>
                    </div>
                    <div class="d-none beds">
                        <lable for="bid_price">Service Provider Amount
                            <input type="number" id="prev" name="prev" class="form-control" min="1" placeholder="Service Provider Amount" readonly>
                        </lable>
                    </div>

                    <div class="comnt d-none">
                        <lable for="cmt">Provider Comment
                            <textarea name="cmt" id="cmt" cols="10" rows="5" class="form-control" required></textarea>
                        </lable>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">back</button>
                    <button type="button" class="btn btn-primary sbmet" onclick="sav()">Submit request</button>
                </div>
            </div>
        </div>
    </div>



    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" integrity="sha512-3pIirOrwegjM6erE5gPSwkUzO+3cTjpnV9lexlNZqvupR64iZBnOOTiiLPb9M36zpMScbmUNIcHUqKD47M719g==" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" integrity="sha512-VEd+nq25CkR676O+pLBnDW09R7VQX9Mdiij052gVCp5yVH3jGtH70Ho/UUv4mJDsEdTvqRCFZg0NKGiojGnUCw==" crossorigin="anonymous"></script>

    <script>
        $(function() {
            $(".progress").each(function() {
                var value = $(this).attr('data-value');
                var left = $(this).find('.progress-left .progress-bar');
                var right = $(this).find('.progress-right .progress-bar');

                if (value > 0) {
                    if (value <= 50) {
                        right.css('transform', 'rotate(' + percentageToDegrees(value) + 'deg)')
                    } else {
                        right.css('transform', 'rotate(180deg)')
                        left.css('transform', 'rotate(' + percentageToDegrees(value - 50) + 'deg)')
                    }
                }
            })
            function percentageToDegrees(percentage) {
                return percentage / 100 * 360
            }

        });
        function showBids(data){
            data=JSON.parse(data);
            console.log(data)
            $('#jqueryTable tbody').html('');
            var html='';
            $.each(data, function (index, value) {
            let rank = parseInt(index) + parseInt(1);
            let status='';
            let status_text='';
            let txt='';
            if(value.approved_status==0) {
                  status = 1;
                  status_text= "<span class='fa fa-pause-circle text-danger'>&nbsp</span>Accept bid";
                 txt= "  ";
            }
            if(value.approved_status==1){
                 status = 2;
                 status_text= "<span class='fa fa-check-circle text-success'> &nbsp</span>Reject bid";
                 txt= " ";
            }
            if(value.approved_status==2){
                txt= "<span class='fa fa-times-circle text-warning'> &nbsp</span>cancelled ";
            }
                html += "<tr class='"+((status==2) ?'bg-success' : '') +"'><td><input type='hidden' id='rank"+index+"' value='"+ rank +"'> " + value.user.name + "<td>" + ((value.created_at!=null) ?value.created_at.substring(0, 16) : '') + "</td><td>" + ((value.user.documents_verified ==1) ? 'Verified' : 'Not verified') + "</td><td >" + ((value.revise_amount_shipper !=null) ? value.revise_amount_shipper : '') + "</td><td >" + value.bid_amount + "</td><td >" + ((value.route!=null) ? value.route : '') +  "</td><td >" + value.last_updated + "</td></td>" +
                    "<td ><a href='#' onclick=\"setStatus('" + value.id+ "','" + value.shipment_id + "','" + status + "')\" > " + status_text + "</a>"+txt+" <br><a href='#' onclick=\"openReviseModal('" + value.id+ "','" + value.bid_amount+ "','" + value.revise_amount_shipper + "','" + value.revise_status + "','"+ index + "','" + value.revise_comment + "')\" >"+((value.revise_status ==0) ? 'request to revise' : ((value.revise_status ==2) ?'<span class="fa fa-pause-circle text-warning"></span> request to revise': ((value.revise_status ==3) ?'<span class="fa fa-times-circle text-danger"></span> request to revise':'')))+" </a></td><tr>";
            });
            $('#jqueryTable').append(html);
            // console.log(data[0]);
        }


        function setStatus(id, shipment_id, approved_status) {
            $.ajax({
                url: "<?php echo e(route('update.bid.status')); ?>",
                type: "get",
                data: {'id': id,'shipment_id': shipment_id,'approved_status':approved_status},
                success: function (result) {
                    toastr.success( 'Status updated successfully');
                    setTimeout(function(){ location.reload() },1000);
                },
                error: function (request, status, error) {
                    // alert(request.responseText);
                    // $('#showBidModal').modal('hide')
                }
            })
        }


        function openReviseModal(id,amount,revised_amount,revise_status, index,revise_comment){
            if(revise_status==2 || revise_status==1 || revise_status==3){
                // alert('sdf');
                // alert();
                $('.beds').removeClass('d-none');
                $('#prev').val(amount);
                $('#amt').val(revised_amount);
                $('.sbmet').addClass('d-none');
            } else{
                $('.sbmet').removeClass('d-none');
                $('.beds').addClass('d-none');
                $('#prev').val(amount);
                $('#amt').val('');
            }
            // alert( revise_comment)
            // if( revise_status==1){
            //     $('#cmt').val(((revise_comment==null) ?'':revise_comment));
            //     $('.comnt').removeClass('d-none');
            // }else{
            //     $('#cmt').val('');
            //     $('.comnt').addClass('d-none');
            // }
            if(revise_comment.length>4){
                $('.comnt').removeClass('d-none');
                $('#cmt').val(((revise_comment==null) ?'':revise_comment));
            }else{
                $('.comnt').addClass('d-none');
            }
            var vaa = $('#rank'+id).val()
            index  = parseInt(index) + parseInt(1);
            $('#rank').val(index)
            $('#bedid').val(id);
            $('#showreviseModal').modal('show')

        }


        function sav() {
            if($('#amt').val()=='' || $('#amt').val()<1){
                $('#amt').addClass('border-danger');
                return ;
            }
            $('#amt').removeClass('border-danger');
            $.ajax({
                url: "<?php echo e(route('sendBidReviserequest')); ?>",
                type: "get",
                data: {'id': $('#bedid').val() ,'rank': $('#rank').val(), 'amt': $('#amt').val()},
                success: function (result){
                    toastr.success( 'Revise request send successfully');
                    $('#showreviseModal').modal('hide')
                    setTimeout(function(){ location.reload() },1000);

                },
                error: function (request, status, error) {
                    // swal.fire(
                    //     'Already bidds',
                    //     'Please waits for approval.',
                    //     'warning');
                    //
                    // $('#showModal').modal('hide')
                }
            })
        }


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ebilty-laravel\resources\views/user/shipment/index.blade.php ENDPATH**/ ?>